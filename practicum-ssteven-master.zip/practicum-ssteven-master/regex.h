#ifndef __REGEX_H__
#define __REGEX_H__

#include <stdbool.h>

/**
 * A regular expression (regexp) that can be used to match against text strings.
 */
typedef struct regex {
    const char *reg;
    int start;
    int end;
} regex_t;

/**
 * Determines if a regular expression matches a path string
 *
 * @param r - regular expression
 * @param path - path string to compare to regular expression
 * @return 1 if the regular expression matches the path, 0 if they do not match.
 */
bool matches(regex_t *r, char *path);

/**
 * Determines if two strings, the pattern and the path, match
 *
 * @param pattern - pattern string to compare to path string
 * @param path - path string to compare to pattern string
 * @return 1 if the two strings match, 0 if they do not match.
 */
bool find_match(char *pattern, char *path);

#endif // #ifndef __REGEX_H__