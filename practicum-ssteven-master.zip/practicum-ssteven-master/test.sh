#!/bin/bash

function check_main() {
    CC="clang"
    CFLAGS="-Wall -g -fsanitize=address,undefined"
    $CC $CFLAGS -c regex.c -o regex.o
    $CC $CFLAGS -c main.c -o main.o
    if $CC $CFLAGS regex.o main.o -o main 2> /dev/null; then \
		echo compilation succeeded; \
	else \
        if $CC $CFLAGS main.o -o main; then \
            echo compilation succeeded; \
        else \
            echo compilation failed; \
            exit 1;
        fi
	fi
    actual=$(./main 'folder' 'folder/folder2/file2')
    if [ "$actual" != "folder/folder2/file2" ]; then \
        echo "correctness failed"
        exit 1;
    fi
    actual=$(./main 'folder' 'folder/folder2/file3')
    if [ "$actual" != "" ]; then \
        echo "correctness failed"
        exit 1;
    fi
    echo "correctness succeeded"
}

function do_test() {
    ./testregex "$1" "$2"
    student=$?
    echo "$2" | grep "^$1$" > /dev/null
    ref=$?
    if [ $student -ne $ref ]; then
        echo "Failed Test: pattern=\"$1\", text=\"$2\", expected $ref, got $student";
        exit 1; # comment out this line to run all tests regardless of whether they pass
    fi
}


check_main

# Write Your Tests Here
# The do_test function tests if your program gives the 
# same result as the reference implementation on the pattern
# and text provided. Feel free to add more lines with 
# more test cases

# Parameter 1 of do_test: pattern
# Parameter 2 of do_test: text
# do_test 'adam' 'hello'
# do_test 'proved' 'proves'
# do_test 'hello' 'hello'
# do_test '' ''
do_test '.....' 'hello'
# do_test 'hi there' 'hello world'
# do_test 'a.c' 'abc'
# do_test 'a.c' 'aec'
# do_test 'uPpER caSE' 'uPPeR cASe'
# do_test '...' '   '
# do_test 'hello\0' 'he\0llo'
# do_test '.' 'a'
# do_test '. . .' 'a b c'
# do_test '. . .' 'abcde'
do_test '' ' '
do_test '' ''
# do_test NULL
# do_test ''
# do_test 'h..lo' 'hello'
do_test 'a*bc' 'abc'
do_test 'a*bc' 'aabc'
do_test 'a*bc' 'bc'
do_test 'a*bc' ''
do_test '.bc' 'abc'
do_test 'a*bc' 'aaabc'
do_test '.*bc' 'aaaaaaaabc'
do_test 'a*bc' 'aaaaabc'
do_test 'hello' ''
do_test 'ab*c' 'abbbbbc'
do_test 'abc*' 'abc'
do_test '.*abcd' 'cd'

echo '-----------------';
echo 'All Tests Passed!';
