#include <stdio.h>
#include <stdlib.h>
#include "regex.h"
#include <string.h>

/*
This file is merely provided to facilitate self-testing 
of your "matches" function. You are free to edit this file
as needed
*/
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: %s <pattern> <text>\n", argv[0]);
        exit(1);
    }

    char *pattern = argv[1]; 
    char *text = argv[2];

    regex_t *regex = malloc(sizeof(regex_t));
    regex->reg = pattern;
    regex->start = 0;
    regex->end = strlen(pattern);

    if (matches(regex, text)) {
        printf("match\n");
        free(regex);
        return 0;
    }
    else {
        printf("no match\n");
        free(regex);
        return 1;
    }
}
