#include <string.h>
#include <stdio.h>
#include "regex.h"
#include <stdlib.h>
#include <stdbool.h>

bool find_match(char *pattern, char *text) {
    char pattern_char = pattern[0];
    char text_char = text[0];

    if (pattern_char == '\0') {
        if (text_char == '\0') {
            return 1;
        }
        else {
            return 0;
        }
    }
    else {
        char second_char = pattern[1];
        if (second_char == '*') {
            if (pattern_char == text_char || (pattern_char == '.' && text_char != '\0')) {
                return find_match(pattern, text + 1) || find_match(pattern + 2, text);
            }
            else {
                return find_match(pattern + 2, text);
            }
        }
    }

    if (pattern_char == text_char || (pattern_char == '.' && text_char != '\0')) {
        return find_match(pattern + 1, text + 1);
    }

    return 0;
}
    

bool matches(regex_t *r, char *path) {
    char *pattern = malloc(r->end + 1);
    strcpy(pattern, r->reg);
    bool result = find_match(pattern, path);
    free(pattern);
    return result;
}