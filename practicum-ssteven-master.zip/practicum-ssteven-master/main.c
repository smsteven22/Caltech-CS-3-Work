#include <stdio.h>
#include <string.h>
#include <dirent.h>
#include <stdlib.h>
#include "regex.h"

const int INITIAL_CHARS = 10000;

char *regex = ".*";
char fullpath[10000] = {0};

char *out[100000];
int len = 0;

char *make_new_string() {
    out[len++] = malloc(sizeof(fullpath));
    strcpy(out[len - 1], fullpath);
    return out[len - 1];
}

int check_special_entry(char *name) {
    if (strcmp(name, ".") == 0) {
        return 1;
    }
    else if (strcmp(name, "..") == 0) {
        return 1;
    }
    else {
        return 0;
    }
}

void find_dir(char *path) {
    regex_t *r = malloc(sizeof(regex_t));
    r->reg = regex;
    r->start = 0;
    r->end = strlen(regex);
    if (matches(r, path)) {
        make_new_string();
    }
    free(r);

    DIR * dir = opendir(path);

    while (dir) {
        struct dirent * entry = readdir(dir);
        int len = strlen(fullpath);
        if (!entry) {
            closedir(dir);
            break;
        }
        if (check_special_entry(entry->d_name)) {
            continue;
        }
        strcat(fullpath, "/");
        strcat(fullpath, entry->d_name);
        find_dir(fullpath);
        fullpath[len] = '\0';
    }
}

int main(int argc, const char* argv[]) {
    char *regex_copy;
    if (argc > 1) {
        regex_copy = malloc(sizeof(char) * INITIAL_CHARS);
        strcpy(regex_copy, argv[argc - 1]);
        regex = regex_copy;
    }

    strcat(fullpath, argv[1]);
    find_dir(fullpath);
    for (int i = 0; i < len; i++) {
        printf("%s\n", out[i]);
    }
    if(argc > 1) {
        free(regex_copy);
    }
}
