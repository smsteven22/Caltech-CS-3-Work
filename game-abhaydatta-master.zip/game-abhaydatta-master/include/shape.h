#ifndef __SHAPE_H__
#define __SHAPE_H__

#include "list.h"
#include "polygon.h"
#include "scene.h"
#include "vector.h"
#include <math.h>
#include <stdio.h>

/**
 * Makes the shape of a pacman and returns the vertices of the shape.
 *
 * @param length - the length of the pacman radius
 * @param center_x - x component of the center of the pacman
 * @param center_y - y-component of the center of the pacman
 */
list_t *make_pacman(size_t length, size_t center_x, size_t center_y);

/**
 * Makes the shape of a star and returns the vertices of the shape.
 *
 * @param length - the length of the star outer radius
 * @param num_points - number of points that the star has (including inner and
 * outer points)
 * @param center_x - x component of the center of the star
 * @param center_y - y-component of the center of the star
 */
list_t *make_star(size_t length, size_t num_points, size_t center_x,
                  size_t center_y);

/**
 * Makes the shape of a circle and returns the vertices required.
 *
 * @param length - the length of the circle radius
 * @param center_x - x component of the center of the circle
 * @param center_y - y-component of the center of the pacman
 */
list_t *make_circle(size_t length, size_t center_x, size_t center_y);

/**
 * Makes the shape of a ellipse and returns the vertices required.
 *
 * @param center_x - x component of the center of the circle
 * @param center_y - y-component of the center of the pacman
 * @param minor - length of the ellipse
 * @param major - width of ellipse
 */
list_t *make_ellipse(size_t center_x, size_t center_y, size_t minor,
                     size_t major);

/**
 * Makes the shape of a rectangle and returns the vertices required.
 *
 * @param length - the length of the rectangle
 * @param width - the width of the rectangle
 * @param center_x - x component of the center of the rectangle
 * @param center_y - y-component of the center of the rectangle
 */
list_t *make_rectangle(size_t length, size_t width, size_t center_x,
                       size_t center_y);

/**
 * Removes shape from scene.
 *
 * @param curr_scene - current scene
 * @param window - vector of window length and window width
 */
void remove_shape(scene_t *curr_scene, vector_t window);

#endif // #ifndef __SHAPE_H__
