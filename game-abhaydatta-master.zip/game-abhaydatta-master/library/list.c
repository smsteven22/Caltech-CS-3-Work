#include "list.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

const size_t GROW_FACTOR = 2;

typedef struct list {
  void **v_list;
  size_t size;
  size_t capacity;
  free_func_t freer;
} list_t;

list_t *list_init(size_t initial_size, free_func_t freer) {
  list_t *new_list = calloc(1, sizeof(list_t));
  assert(new_list != NULL);
  new_list->v_list = calloc(initial_size, sizeof(void *));
  assert(new_list->v_list != NULL);

  new_list->size = 0;
  new_list->capacity = initial_size;
  new_list->freer = freer;

  return new_list;
}

size_t list_size(list_t *list) {
  assert(list != NULL);
  return list->size;
}

void *list_get(list_t *list, size_t index) {
  assert(list->size > 0);
  assert(index >= 0);
  assert(index < list->size);
  return list->v_list[index];
}

void *list_remove(list_t *list, size_t index) {
  assert(list->size != 0);
  assert(index < list->size);
  void *to_return = list_get(list, index);

  for (size_t i = index + 1; i < list->size; i++) {
    list->v_list[i - 1] = list->v_list[i];
  }

  list->size--;

  return to_return;
}

void list_add(list_t *list, void *value) {
  if (list->size == list->capacity) {
    if (list->capacity == 0) {
      list->capacity = 1;
    }
    size_t new_capacity = list->capacity * GROW_FACTOR;
    list->v_list = realloc(list->v_list, sizeof(void *) * new_capacity);
    list->capacity = new_capacity;
  }

  assert(list->size < list->capacity);
  assert(value != NULL);

  list->v_list[list->size] = value;
  list->size++;
}

void list_free(list_t *list) {
  for (size_t i = 0; i < list_size(list); i++) {
    if (list->freer != NULL) {
      (list->freer)(list->v_list[i]);
    }
  }
  list->size = 0;
  free(list->v_list);
  free(list);
}

list_t *list_merge(list_t *list_of_lists) {
  list_t *new_list = list_init(1, NULL);
  for (size_t i = 0; i < list_size(list_of_lists); i++) {\
    list_t *each_list = (list_t *)list_get(list_of_lists, i);
    for (size_t j = 0; j < list_size(each_list); j++) {
      list_add(new_list, list_get(each_list, j));
    }
  }
  return new_list;
}
