#include "forces.h"
#include "body.h"
#include "collision.h"
#include "color.h"
#include "list.h"
#include "scene.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

const double MIN_DIST = 5;

typedef struct force {
  force_creator_t forcer;
  void *aux;
  free_func_t freer;
} force_t;

typedef struct impulse {
  collision_handler_t handler;
  body_t *body1;
  body_t *body2;
  void *aux;
  bool prev_collision;
  vector_t axis;
  free_func_t freer;
} impulse_t;

typedef struct grav_aux {
  body_t *body1;
  body_t *body2;
  double grav_const;
} grav_aux_t;

typedef struct spring_aux {
  body_t *body1;
  body_t *body2;
  double spring_const;
} spring_aux_t;

typedef struct drag_aux {
  body_t *body;
  double drag_const;
} drag_aux_t;

typedef struct collision_aux {
  body_t *body1;
  body_t *body2;
  double elasticity;
  vector_t collision_axis;
} collision_aux_t;

void aux_free(void *aux) { free(aux); }

void force_free(force_t *force) {
  free_func_t freer = force->freer;
  if (freer != NULL) {
    freer(force->aux);
  }
  free(force);
}

void impulse_free(impulse_t *impulse) {
  free_func_t freer = impulse->freer;
  if (freer != NULL) {
    freer(impulse->aux);
  }
  free(impulse);
}

force_t *force_init(force_creator_t forcer, void *aux) {
  force_t *new_force = malloc(sizeof(force_t));
  new_force->forcer = forcer;
  new_force->aux = aux;
  return new_force;
}

void force_set_freer(force_t *force, free_func_t freer) {
  force->freer = freer;
}

vector_t get_distance(body_t *body1, body_t *body2) {
  vector_t pos1 = body_get_centroid(body1);
  vector_t pos2 = body_get_centroid(body2);
  vector_t distance = vec_subtract(pos2, pos1);
  return distance;
}

void get_gravity(grav_aux_t *aux) {
  body_t *body1 = aux->body1;
  body_t *body2 = aux->body2;
  double g = aux->grav_const;

  vector_t distance = get_distance(body1, body2);

  double dist_norm =
      sqrt((distance.x * distance.x) + (distance.y * distance.y));

  vector_t d_hat = vec_multiply(1.0 / dist_norm, distance);

  vector_t force = VEC_ZERO;
  if (dist_norm > MIN_DIST) {
    double full_f = (g * body_get_mass(body1) * body_get_mass(body2)) /
                    (dist_norm * dist_norm);

    force = vec_multiply(full_f, d_hat);
  }
  body_add_force(body1, force);
  body_add_force(body2, vec_negate(force));
}

void create_newtonian_gravity(scene_t *scene, double G, body_t *body1,
                              body_t *body2) {
  grav_aux_t *grav_aux = malloc(sizeof(grav_aux_t));
  grav_aux->body1 = body1;
  grav_aux->body2 = body2;
  grav_aux->grav_const = G;

  list_t *bodies_list = list_init(2, NULL);
  list_add(bodies_list, body1);
  list_add(bodies_list, body2);

  scene_add_bodies_force_creator(scene, (force_creator_t)get_gravity,
                                 (void *)grav_aux, bodies_list, aux_free);
}

void get_spring(spring_aux_t *aux) {
  body_t *body1 = aux->body1;
  body_t *body2 = aux->body2;
  double k = aux->spring_const;
  vector_t distance = get_distance(body1, body2);

  vector_t force = VEC_ZERO;
  force = vec_multiply(-k, distance);

  body_add_force(body1, vec_negate(force));
  body_add_force(body2, force);
}

void create_spring(scene_t *scene, double k, body_t *body1, body_t *body2) {
  spring_aux_t *spring_aux = malloc(sizeof(spring_aux_t));
  spring_aux->body1 = body1;
  spring_aux->body2 = body2;
  spring_aux->spring_const = k;

  list_t *bodies_list = list_init(2, NULL);
  list_add(bodies_list, body1);
  list_add(bodies_list, body2);

  scene_add_bodies_force_creator(scene, (force_creator_t)get_spring, spring_aux,
                                 bodies_list, aux_free);
}

void get_drag(drag_aux_t *aux) {
  double gamma = aux->drag_const;
  body_t *body = aux->body;
  vector_t force = VEC_ZERO;
  vector_t velocity = body_get_velocity(body);
  force = vec_multiply(-gamma, velocity);

  body_add_force(body, force);
}

void create_drag(scene_t *scene, double gamma, body_t *body) {
  drag_aux_t *drag_aux = malloc(sizeof(drag_aux_t));
  drag_aux->body = body;
  drag_aux->drag_const = gamma;

  list_t *bodies_list = list_init(2, NULL);
  list_add(bodies_list, body);

  scene_add_bodies_force_creator(scene, (force_creator_t)get_drag,
                                 (void *)drag_aux, bodies_list, aux_free);
}

void get_destructive_collision(collision_aux_t *aux) {
  list_t *shape1 = body_get_actual_shape(aux->body1);
  list_t *shape2 = body_get_actual_shape(aux->body2);

  if (get_collision_bool(find_collision(shape1, shape2)) == 1) {
    body_remove(aux->body1);
    body_remove(aux->body2);
  }
}

void create_destructive_collision(scene_t *scene, body_t *body1,
                                  body_t *body2) {
  collision_aux_t *destruct_aux = malloc(sizeof(collision_aux_t));
  destruct_aux->body1 = body1;
  destruct_aux->body2 = body2;

  list_t *bodies_list = list_init(2, NULL);
  list_add(bodies_list, body1);
  list_add(bodies_list, body2);

  scene_add_bodies_force_creator(scene,
                                 (force_creator_t)get_destructive_collision,
                                 (void *)destruct_aux, bodies_list, aux_free);
}

void get_collision(impulse_t *auxy) {
  body_t *body1 = auxy->body1;
  body_t *body2 = auxy->body2;
  collision_info_t collision = find_collision(body_get_actual_shape(body1),
                                              body_get_actual_shape(body2));
  collision_handler_t handler = auxy->handler;
  if (get_collision_bool(collision) == 1 && (auxy->prev_collision == 0)) {
    handler(auxy->body1, auxy->body2, get_collision_axis(collision), auxy->aux);
    auxy->prev_collision = 1;
  } else if (get_collision_bool(collision) == 0) {
    auxy->prev_collision = 0;
  }
}

void create_collision(scene_t *scene, body_t *body1, body_t *body2,
                      collision_handler_t handler, void *aux,
                      free_func_t freer) {

  impulse_t *new_handler_aux = malloc(sizeof(impulse_t));
  new_handler_aux->aux = aux;
  new_handler_aux->body1 = body1;
  new_handler_aux->body2 = body2;
  new_handler_aux->freer = freer;
  new_handler_aux->handler = handler;

  list_t *bodies_list = list_init(2, NULL);
  list_add(bodies_list, body1);
  list_add(bodies_list, body2);

  scene_add_bodies_force_creator(scene, (force_creator_t)get_collision,
                                 new_handler_aux, bodies_list, freer);
}

void handle_one_destructive_collision(body_t *body1, body_t *body2,
                                      vector_t axis, void *aux) {
  list_t *shape1 = body_get_actual_shape(body1);
  list_t *shape2 = body_get_actual_shape(body2);

  if (get_collision_bool(find_collision(shape1, shape2))) {
    body_remove(body2);
  }
}

void create_one_destructive_collision(scene_t *scene, body_t *body1,
                                      body_t *body2) {
  collision_aux_t *collision_aux = malloc(sizeof(collision_aux_t));
  collision_aux->body1 = body1;
  collision_aux->body2 = body2;
  collision_aux->elasticity = 0;

  list_t *shape1 = body_get_actual_shape(body1);
  list_t *shape2 = body_get_actual_shape(body2);
  collision_aux->collision_axis =
      get_collision_axis(find_collision(shape1, shape2));
  create_collision(scene, body1, body2,
                   (collision_handler_t)handle_one_destructive_collision,
                   collision_aux, aux_free);
}

void handle_physics_collision(body_t *body1, body_t *body2, vector_t axis,
                              void *aux) {
  double cr = ((collision_aux_t *)aux)->elasticity;

  double m1 = body_get_mass(body1);
  vector_t v1 = body_get_velocity(body1);
  double ua = vec_dot(v1, axis);

  double m2 = body_get_mass(body2);
  vector_t v2 = body_get_velocity(body2);
  double ub = vec_dot(v2, axis);

  double j = ((m1 * m2) / (m1 + m2)) * (1 + cr) * (ub - ua);

  if (m1 == INFINITY && m2 != INFINITY) {
    j = m2 * (1 + cr) * (ub - ua);
  } else if (m2 == INFINITY && m1 != INFINITY) {
    j = m1 * (1 + cr) * (ub - ua);
  }

  vector_t impulse = vec_multiply(j, axis);

  body_add_impulse(body1, impulse);
  body_add_impulse(body2, vec_negate(impulse));
}

void create_physics_collision(scene_t *scene, double elasticity, body_t *body1,
                              body_t *body2) {
  collision_aux_t *collision_aux = malloc(sizeof(collision_aux_t));
  collision_aux->body1 = body1;
  collision_aux->body2 = body2;
  collision_aux->elasticity = elasticity;

  list_t *shape1 = body_get_actual_shape(body1);
  list_t *shape2 = body_get_actual_shape(body2);
  collision_aux->collision_axis =
      get_collision_axis(find_collision(shape1, shape2));
  create_collision(scene, body1, body2,
                   (collision_handler_t)handle_physics_collision, collision_aux,
                   aux_free);
}

void *get_force_aux(force_t *force) { return force->aux; }

force_creator_t get_force_forcer(force_t *force) { return force->forcer; }
