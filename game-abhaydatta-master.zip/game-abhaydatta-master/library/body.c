#include "color.h"
#include "forces.h"
#include "list.h"
#include "polygon.h"
#include "vector.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

const double DEFAULT_ROT_ANGLE = 0;

typedef struct body {
  list_t *shape;
  rgb_color_t color;
  double mass;
  vector_t position;
  vector_t velocity;
  double rot_angle;
  vector_t full_force;
  vector_t full_impulse;
  void *info;
  free_func_t info_freer;
  bool to_remove;
  double score;
} body_t;

body_t *body_init(list_t *shape, double mass, rgb_color_t color) {
  return body_init_with_info(shape, mass, color, NULL, NULL);
}

body_t *body_init_with_info(list_t *shape, double mass, rgb_color_t color,
                            void *info, free_func_t info_freer) {
  body_t *new_body = malloc(sizeof(body_t));
  new_body->shape = shape;
  assert(mass > 0);
  new_body->mass = mass;
  new_body->color = color;
  new_body->position = polygon_centroid(shape);
  new_body->velocity = VEC_ZERO;
  new_body->rot_angle = DEFAULT_ROT_ANGLE;
  new_body->full_force = VEC_ZERO;
  new_body->full_impulse = VEC_ZERO;
  new_body->info = info;
  new_body->info_freer = info_freer;
  new_body->to_remove = 0;
  new_body->score = 0.0;
  return new_body;
}

void body_free(body_t *body) {
  list_free(body->shape);
  free_func_t freer = body->info_freer;
  if (freer != NULL) {
    freer(body->info);
  }
  free(body);
}

list_t *body_get_shape(body_t *body) {
  size_t len = list_size(body->shape);
  list_t *to_return = list_init(len, (free_func_t)free);
  for (size_t i = 0; i < len; i++) {
    vector_t *vertex = malloc(sizeof(vector_t));
    vector_t *old_vertex = (vector_t *)list_get(body->shape, i);
    vertex->x = old_vertex->x;
    vertex->y = old_vertex->y;
    list_add(to_return, vertex);
  }
  return to_return;
}

list_t *body_get_actual_shape(body_t *body) { return body->shape; }

vector_t body_get_centroid(body_t *body) { return body->position; }

vector_t body_get_velocity(body_t *body) { return body->velocity; }

double body_get_mass(body_t *body) { return body->mass; }

rgb_color_t body_get_color(body_t *body) { return body->color; }

void *body_get_info(body_t *body) { return body->info; }

vector_t body_get_full_force(body_t *body) { return body->full_force; }

vector_t body_get_full_impulse(body_t *body) { return body->full_impulse; }

void body_set_centroid(body_t *body, vector_t x) {
  list_t *vertices = body->shape;
  vector_t dist = vec_subtract(x, body->position);
  polygon_translate(vertices, dist);
  body->position = x;
}

void body_set_velocity(body_t *body, vector_t v) { body->velocity = v; }

void body_set_rotation(body_t *body, double angle) {
  double curr_angle = body->rot_angle;
  list_t *vertices = body->shape;
  polygon_rotate(vertices, (angle - curr_angle), body->position);
  body->rot_angle = angle;
}

void body_set_color(body_t *body, rgb_color_t color) { body->color = color; }

void body_set_mass(body_t *body, double mass) { body->mass = mass; }

void body_add_force(body_t *body, vector_t force) {
  vector_t full_f = body->full_force;
  full_f = vec_add(full_f, force);
  body->full_force = full_f;
}

void body_add_impulse(body_t *body, vector_t impulse) {
  vector_t full_i = body->full_impulse;
  full_i = vec_add(full_i, impulse);
  body->full_impulse = full_i;
}

void body_tick(body_t *body, double dt) {
  vector_t vel_1 = vec_multiply(1.0 / body_get_mass(body), body->full_impulse);
  vector_t vel_2 = vec_add(
      body->velocity, vec_multiply(dt / body_get_mass(body), body->full_force));
  vector_t new_vel = vec_add(vel_1, vel_2);

  vector_t set_vel = vec_multiply(0.5, vec_add(new_vel, body->velocity));
  vector_t dist = vec_multiply(dt, set_vel);
  body_set_centroid(body, vec_add(body->position, dist));

  body->velocity = new_vel;
  body->full_force = VEC_ZERO;
  body->full_impulse = VEC_ZERO;
}

void body_remove(body_t *body) {
  body->to_remove = 1;
  body->color = (rgb_color_t){1.0, 1.0, 1.0};
}

bool body_is_removed(body_t *body) { return body->to_remove; }

double body_get_score(body_t *body) { return body->score; }

void body_set_score(body_t *body, double score) { body->score = score; }
