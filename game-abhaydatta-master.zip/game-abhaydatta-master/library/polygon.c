#include "polygon.h"
#include "list.h"
#include "vector.h"
#include <math.h>
#include <stdio.h>

double polygon_area(list_t *polygon) {
  double sum = 0.0;
  size_t vec_size = list_size(polygon);
  for (size_t i = 0; i < vec_size; i++) {
    vector_t *v1 = list_get(polygon, i);
    vector_t *v2 = list_get(polygon, (i + 1) % vec_size);

    sum += vec_cross(*v1, *v2);
  }
  return sum / 2;
}

vector_t polygon_centroid(list_t *polygon) {
  double center_x = 0.0;
  double center_y = 0.0;
  size_t vec_size = list_size(polygon);
  double area = polygon_area(polygon);
  for (size_t i = 0; i < vec_size; i++) {
    vector_t *v1 = list_get(polygon, i % vec_size);
    vector_t *v2 = list_get(polygon, (i + 1) % vec_size);

    center_x += ((v1->x + v2->x) * (vec_cross(*v1, *v2)));
    center_y += ((v1->y + v2->y) * (vec_cross(*v1, *v2)));
  }

  vector_t centroid = {center_x / (6 * area), center_y / (6 * area)};
  return centroid;
}

void polygon_translate(list_t *polygon, vector_t translation) {
  for (size_t i = 0; i < list_size(polygon); i++) {
    vector_t *v = list_get(polygon, i);
    v->x += translation.x;
    v->y += translation.y;
  }
}

void polygon_rotate(list_t *polygon, double angle, vector_t point) {
  polygon_translate(polygon, vec_negate(point));
  for (size_t i = 0; i < list_size(polygon); i++) {
    vector_t *v = list_get(polygon, i);
    vector_t temp = vec_rotate(*v, angle);
    v->x = temp.x;
    v->y = temp.y;
  }
  polygon_translate(polygon, point);
}
