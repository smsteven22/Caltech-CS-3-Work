#include "body.h"
#include "forces.h"
#include "list.h"
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

const size_t NUM_BODY_GUESS = 25;

typedef struct scene {
  list_t *bodies_list;
  double total_time;
  list_t *force_creators;
  list_t *force_bodies;
} scene_t;

scene_t *scene_init() {
  scene_t *new_scene = malloc(sizeof(scene_t));
  list_t *new_scene_list = list_init(NUM_BODY_GUESS, (free_func_t)body_free);
  new_scene->total_time = 0.0;
  assert(new_scene_list != NULL);
  new_scene->bodies_list = new_scene_list;

  list_t *new_force_list = list_init(NUM_BODY_GUESS, (free_func_t)force_free);
  new_scene->force_creators = new_force_list;

  list_t *new_body_force_list =
      list_init(NUM_BODY_GUESS, (free_func_t)list_free);
  new_scene->force_bodies = new_body_force_list;

  return new_scene;
}

void scene_free(scene_t *scene) {
  list_free(scene->force_creators);

  for (size_t i = 0; i < list_size(scene->force_bodies); i++) {
    for (size_t j = 0; j < list_size(list_get(scene->force_bodies, i)); j++) {
      list_remove(list_get(scene->force_bodies, i), j);
    }
  }
  list_free(scene->force_bodies);
  list_free(scene->bodies_list);
  free(scene);
}

size_t scene_bodies(scene_t *scene) { return list_size(scene->bodies_list); }

body_t *scene_get_body(scene_t *scene, size_t index) {
  assert(index < scene_bodies(scene));
  return list_get(scene->bodies_list, index);
}

void scene_add_body(scene_t *scene, body_t *body) {
  list_add(scene->bodies_list, body);
}

void scene_remove_body(scene_t *scene, size_t index) {
  assert(index < scene_bodies(scene));
  list_t *bodies = scene->bodies_list;
  body_remove(list_get(bodies, index));
}

void scene_add_force_creator(scene_t *scene, force_creator_t forcer, void *aux,
                             free_func_t freer) {
  list_t *bodies = list_init(1, NULL);
  scene_add_bodies_force_creator(scene, forcer, aux, bodies, freer);
}

void scene_add_bodies_force_creator(scene_t *scene, force_creator_t forcer,
                                    void *aux, list_t *bodies,
                                    free_func_t freer) {
  force_t *new_force = force_init(forcer, aux);
  force_set_freer(new_force, freer);

  list_add(scene->force_creators, new_force);
  list_add(scene->force_bodies, bodies);
}

list_t *get_force_creators(scene_t *scene) { return scene->force_creators; }

list_t *get_force_bodies(scene_t *scene, size_t idx) {
  return list_get(scene->force_bodies, idx);
}

void scene_tick(scene_t *scene, double dt) {
  list_t *forces = scene->force_creators;
  // applying all the forces
  for (size_t j = 0; j < list_size(forces); j++) {
    force_t *each_force = list_get(forces, j);
    force_creator_t forcer = get_force_forcer(each_force);
    void *aux = get_force_aux(each_force);
    forcer(aux);
  }

  // checking for deferred removals
  for (size_t i = 0; i < list_size(forces); i++) {
    list_t *each_body_list = list_get(scene->force_bodies, i);

    // removing all flagged bodies
    for (size_t j = 0; j < list_size(each_body_list); j++) {
      body_t *check_body = list_get(each_body_list, j);

      if (body_is_removed(check_body)) {
        // free the corresponding force_t
        force_t *removed = list_remove(forces, i);

        force_free(removed);

        // free the body list that has the removed body
        list_t *bodies_removed = list_remove(scene->force_bodies, i);
        for (size_t k = 0; k < list_size(bodies_removed); k++) {
          list_remove(bodies_removed, k);
          k--;
        }
        list_free(bodies_removed);
        i--;
        break;
      }
    }
  }

  // actually freeing the removed bodies
  ssize_t len = scene_bodies(scene);
  for (ssize_t i = 0; i < len; i++) {
    body_t *to_check = list_get(scene->bodies_list, i);
    if (body_is_removed(to_check)) {
      to_check = list_remove(scene->bodies_list, i);
      body_free(to_check);
      i--;
      len--;
    }
  }

  // ticking all the bodies
  for (size_t i = 0; i < scene_bodies(scene); i++) {
    body_t *each_body = scene_get_body(scene, i);
    body_tick(each_body, dt);
  }
}

list_t *get_scene_list(scene_t *scene) { return scene->bodies_list; }

double get_tot(scene_t *scene) { return scene->total_time; }

void set_tot(scene_t *scene, double tot) { scene->total_time = tot; }
