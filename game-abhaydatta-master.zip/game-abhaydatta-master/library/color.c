#include "color.h"
#include <stdlib.h>

rgb_color_t color_init(double r, double g, double b) {
  rgb_color_t *to_return = malloc(sizeof(rgb_color_t));
  to_return->r = r;
  to_return->g = g;
  to_return->b = b;
  return *to_return;
}
