#include "collision.h"
#include "forces.h"
#include "list.h"
#include "vector.h"
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

list_t *get_perp_axes(list_t *shape1, list_t *shape2) {
  size_t edges1 = list_size(shape1);
  size_t edges2 = list_size(shape2);

  list_t *perp_axes =
      list_init((list_size(shape1) + list_size(shape2) + 1), (free_func_t)free);

  // find and store the perpendicular axes as unit vectors in one list
  for (size_t i = 0; i < edges1; i++) {
    vector_t *vertex1 = list_get(shape1, ((i + 1) % edges1));
    vector_t *vertex2 = list_get(shape1, i);
    vector_t edge = vec_subtract(*vertex2, *vertex1);

    vector_t *perp_norm = malloc(sizeof(vector_t));
    *perp_norm = vec_normalize((vector_t){-edge.y, edge.x});

    list_add(perp_axes, perp_norm);
  }

  for (size_t i = 0; i < edges2; i++) {
    vector_t *vertex1 = list_get(shape2, ((i + 1) % edges2));
    vector_t *vertex2 = list_get(shape2, i);
    vector_t edge = vec_subtract(*vertex2, *vertex1);

    vector_t *perp_norm = malloc(sizeof(vector_t));
    *perp_norm = vec_normalize((vector_t){-edge.y, edge.x});

    list_add(perp_axes, perp_norm);
  }
  return perp_axes;
}

vector_t proj_polygon(list_t *shape, vector_t *unit_line) {
  vector_t *vertex0 = list_get(shape, 0);
  vector_t *vertex_last = list_get(shape, list_size(shape) - 1);
  double max = vec_dot(*unit_line, *vertex0);
  double min = vec_dot(*unit_line, *vertex_last);

  size_t num_vertices = list_size(shape);

  // for each vertex, see if the max proj or min proj is more or less than
  // before store the max and min for the entire polygon, and return that as the
  // final projection
  for (size_t j = 0; j < num_vertices; j++) {
    vector_t *vertex = list_get(shape, j);
    double proj = vec_dot(*unit_line, *vertex);
    if (proj > max) {
      max = proj;
    }
    if (proj < min) {
      min = proj;
    }
  }
  vector_t projection = {min, max};
  return projection;
}

collision_info_t find_collision(list_t *shape1, list_t *shape2) {
  // collision_info_t *to_return = malloc(sizeof(collision_info_t));
  collision_info_t to_return;
  size_t counter = 0;
  list_t *perp_axes = get_perp_axes(shape1, shape2);

  vector_t proj_1 = proj_polygon(shape1, list_get(perp_axes, 0));
  vector_t proj_2 = proj_polygon(shape2, list_get(perp_axes, 0));

  size_t num_axes = list_size(perp_axes);
  double min_dist = fmin(proj_1.y, proj_2.y) - fmax(proj_1.x, proj_2.x);
  size_t min_idx = 0;
  for (size_t i = 0; i < num_axes; i++) {
    vector_t *each_axis = list_get(perp_axes, i);
    vector_t proj1 = proj_polygon(shape1, each_axis);
    vector_t proj2 = proj_polygon(shape2, each_axis);

    if ((proj1.y >= proj2.x) && (proj1.x <= proj2.y)) {
      counter++;
      double overlap = fmin(proj1.y, proj2.y) - fmax(proj1.x, proj2.x);
      if (min_dist > overlap) {
        min_dist = overlap;
        min_idx = i;
      }
    } else {
      to_return.collided = 0;
      break;
    }
  }

  if (counter == num_axes) {
    to_return.collided = 1;
    vector_t *coll_axis = list_get(perp_axes, min_idx);
    to_return.axis = *coll_axis;
  }

  list_free(perp_axes);
  return to_return;
}

bool get_collision_bool(collision_info_t collision) {
  return collision.collided;
}

vector_t get_collision_axis(collision_info_t collision) {
  return collision.axis;
}

void set_collision_bool(collision_info_t collision, bool collided) {
  collision.collided = collided;
}

void set_collision_axis(collision_info_t collision, vector_t axis) {
  collision.axis = axis;
}
