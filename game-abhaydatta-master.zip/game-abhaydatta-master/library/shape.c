#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#include "list.h"
#include "polygon.h"
#include "scene.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

const double RAD_RATIO = 0.5;
const size_t CIRC_POINTS = 20;
const size_t PAC_POINTS = 7;
const size_t RECT_POINTS = 4;

const double TWO_PI = 2.0 * M_PI;
const double HALF = 0.5;

list_t *make_pacman(size_t length, size_t center_x, size_t center_y) {
  double curr_angle = 0;
  double vert_angle = TWO_PI / CIRC_POINTS;
  double x;
  double y;
  list_t *vertices = list_init(CIRC_POINTS, (free_func_t)free);
  assert(vertices != NULL);
  for (size_t i = 0; i < CIRC_POINTS; i++) {
    x = cos(curr_angle) + center_x;
    y = sin(curr_angle) + center_y;
    vector_t *vertex = malloc(sizeof(vector_t));
    vertex->x = x;
    vertex->y = y;
    list_add(vertices, vertex);
    curr_angle += vert_angle;
  }
  for (size_t i = 0; i < CIRC_POINTS - PAC_POINTS; i++) {
    x = cos(curr_angle) * length + center_x;
    y = sin(curr_angle) * length + center_y;
    vector_t *vertex = malloc(sizeof(vector_t));
    vertex->x = x;
    vertex->y = y;
    list_add(vertices, vertex);
    curr_angle += vert_angle;
  }
  return vertices;
}

list_t *make_star(size_t length, size_t num_points, size_t center_x,
                  size_t center_y) {
  double curr_angle = 0;
  double vert_angle = TWO_PI / num_points;
  double x = 0.0;
  double y = 0.0;

  list_t *vertices = list_init(num_points, (free_func_t)free);

  for (size_t i = 0; i < num_points; i++) {
    if (i % 2 == 0) {
      x = cos(curr_angle) * length + center_x;
      y = sin(curr_angle) * length + center_y;
      vector_t *vertex = malloc(sizeof(vector_t));
      vertex->x = x;
      vertex->y = y;

      list_add(vertices, vertex);
      curr_angle += vert_angle;
    } else {
      x = cos(curr_angle) * length * RAD_RATIO + center_x;
      y = sin(curr_angle) * length * RAD_RATIO + center_y;

      vector_t *vertex = malloc(sizeof(vector_t));
      vertex->x = x;
      vertex->y = y;
      list_add(vertices, vertex);
      curr_angle += vert_angle;
    }
  }
  return vertices;
}

list_t *make_circle(size_t length, size_t center_x, size_t center_y) {
  double curr_angle = 0;
  double vert_angle = TWO_PI / CIRC_POINTS;
  double x;
  double y;
  list_t *vertices = list_init(CIRC_POINTS, (free_func_t)free);
  assert(vertices != NULL);
  for (size_t i = 0; i < CIRC_POINTS; i++) {
    x = cos(curr_angle) * length + center_x;
    y = sin(curr_angle) * length + center_y;
    vector_t *vec_ptr = malloc(sizeof(vector_t));
    vec_ptr->x = x;
    vec_ptr->y = y;
    list_add(vertices, vec_ptr);
    curr_angle += vert_angle;
  }
  return vertices;
}

list_t *make_ellipse(size_t length, size_t center_x, size_t center_y,
                     size_t minor, size_t major) {
  double curr_angle = 0;
  double vert_angle = TWO_PI / CIRC_POINTS;
  double x;
  double y;
  list_t *vertices = list_init(CIRC_POINTS, (free_func_t)free);
  assert(vertices != NULL);
  for (size_t i = 0; i < CIRC_POINTS; i++) {
    x = cos(curr_angle) * minor + center_x;
    y = sin(curr_angle) * major + center_y;
    vector_t *vec_ptr = malloc(sizeof(vector_t));
    vec_ptr->x = x;
    vec_ptr->y = y;
    list_add(vertices, vec_ptr);
    curr_angle += vert_angle;
  }
  return vertices;
}

list_t *make_rectangle(size_t length, size_t width, size_t center_x,
                       size_t center_y) {
  list_t *vertices = list_init(RECT_POINTS, (free_func_t)free);
  assert(vertices != NULL);

  double x;
  double y;

  // Top Left Vertex
  vector_t *top_left = malloc(sizeof(vector_t));
  x = center_x - (width * HALF);
  y = center_y + (length * HALF);
  top_left->x = x;
  top_left->y = y;
  list_add(vertices, top_left);

  // Top Right Vertex
  vector_t *top_right = malloc(sizeof(vector_t));
  x = center_x + (width * HALF);
  top_right->x = x;
  top_right->y = y;
  list_add(vertices, top_right);

  // Bottom Right Vertex
  vector_t *bottom_right = malloc(sizeof(vector_t));
  y = center_y - (length * HALF);
  bottom_right->x = x;
  bottom_right->y = y;
  list_add(vertices, bottom_right);

  // Bottom Left Vertex
  vector_t *bottom_left = malloc(sizeof(vector_t));
  x = center_x - (width * HALF);
  bottom_left->x = x;
  bottom_left->y = y;
  list_add(vertices, bottom_left);

  return vertices;
}

void remove_shape(scene_t *curr_scene, vector_t window) {
  size_t vertices_out = 0;
  body_t *curr_body = scene_get_body(curr_scene, 0);
  list_t *curr_shape = body_get_shape(curr_body);
  for (size_t i = 0; i < list_size(curr_shape); i++) {
    if (((vector_t *)list_get(curr_shape, i))->x >= window.x) {
      vertices_out++;
    }
  }

  if (vertices_out == list_size(curr_shape)) {
    scene_remove_body(curr_scene, 0);
  }

  vertices_out = 0;
}
