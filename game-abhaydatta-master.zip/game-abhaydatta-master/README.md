Please look at the image-rendering branch instead of the master branch for the final version of the game. Enjoy!!
