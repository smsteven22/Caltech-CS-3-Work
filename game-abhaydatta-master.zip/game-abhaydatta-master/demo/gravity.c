#include "body.h"
#include "color.h"
#include "list.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "vector.h"
#include <assert.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include "shape.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const size_t RADIUS = 30;
const double ROT_ANGLE = 0.05;
const size_t MIN_NUM_SHAPES = 1;
const size_t MIN_NUM_POINTS = 4;

const double GRAVITY = 98;
const double RESTITUTION_COEFF = 0.90;
const size_t MIN_VEL = 100;
const size_t MAX_VEL = 140;
const size_t SPAWN_WAIT_TIME = 3;

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const vector_t CENTROID = (vector_t){.x = RADIUS, .y = 500 - RADIUS};

typedef struct state {
  scene_t *scene;
} state_t;

void update_vel(body_t *poly, vector_t curr_velocity, double dt) {
  list_t *vertices = body_get_shape(poly);
  for (size_t i = 0; i < list_size(vertices); i++) {
    vector_t distance = vec_multiply(dt, body_get_velocity(poly));
    vector_t *vector = list_get(vertices, i);
    double y = vector->y + distance.y;
    size_t changed = 0;
    vector_t curr_vel = body_get_velocity(poly);
    if (y <= 0) {
      body_set_velocity(
          poly, (vector_t){curr_vel.x, curr_vel.y * -1 * RESTITUTION_COEFF});
      changed = 1;
    } else {
      body_set_velocity(poly,
                        (vector_t){curr_vel.x, (curr_vel.y - GRAVITY * dt)});
      ;
    }
    if (changed == 1) {
      break;
    }
  }
}

// makes a list of all the polygon vertices that we need for the entire sequence
void populate_poly_list(scene_t *curr_scene, size_t numpoints) {
  srand(time(NULL));
  list_t *shape = make_star(RADIUS, numpoints, CENTROID.x, CENTROID.y);
  rgb_color_t *color = malloc(sizeof(rgb_color_t));
  color->r = (rand() % 255) / 255.0;
  color->g = (rand() % 255) / 255.0;
  color->b = (rand() % 255) / 255.0;
  body_t *to_add = body_init(shape, polygon_area(shape), *color);
  body_set_velocity(to_add,
                    (vector_t){(MIN_VEL + (rand() % (MAX_VEL - MIN_VEL))), 0});
  scene_add_body(curr_scene, to_add);
}

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;

  sdl_init(min, max);
  state_t *new_state = malloc(sizeof(state_t));
  scene_t *gravity = scene_init();
  populate_poly_list(gravity, MIN_NUM_POINTS);

  new_state->scene = gravity;

  return new_state;
}

size_t remove_counter = 0;
size_t spawn_counter = 0;
double tot = 0.0;

void emscripten_main(state_t *state) {
  double dt = time_since_last_tick();
  scene_t *curr_scene = state->scene;
  tot += dt;
  for (size_t i = 0; i < scene_bodies(curr_scene); i++) {
    body_t *curr_body = scene_get_body(curr_scene, i);
    list_t *curr_body_vertices = body_get_actual_shape(curr_body);
    vector_t curr_body_vel = body_get_velocity(curr_body);

    vector_t distance = vec_multiply(dt, curr_body_vel);
    polygon_translate(curr_body_vertices, distance);

    vector_t center = polygon_centroid(curr_body_vertices);
    polygon_rotate(curr_body_vertices, ROT_ANGLE, center);

    sdl_render_scene(curr_scene);

    update_vel(curr_body, curr_body_vel, dt);
  }

  if (((double)tot / SPAWN_WAIT_TIME) >= 1.0) {
    body_t *last_body =
        scene_get_body(curr_scene, scene_bodies(curr_scene) - 1);
    size_t last_vertices = list_size(body_get_shape(last_body));
    size_t new_numpoints = last_vertices + 2;
    populate_poly_list(curr_scene, new_numpoints);
    tot = 0.0;
  }
  remove_shape(curr_scene, WINDOW);
}

// free everything
void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
