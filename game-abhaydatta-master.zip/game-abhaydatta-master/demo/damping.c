#include "body.h"
#include "color.h"
#include "forces.h"
#include "list.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const vector_t CENTROID = (vector_t){.x = 250, .y = 250};

const vector_t VEL_INITIAL = {100, 100};

const size_t NUM_BODIES = 100;
const size_t QUARTER_BODIES = NUM_BODIES / 4;
const double SPRING_CONST = 100;
const double DRAG_CONST = 40;

const double MAX_COLOR = 1.0;
const double MIN_COLOR = 0.0;

typedef struct state {
  scene_t *scene;
} state_t;

void populate_body_list(scene_t *curr_scene) {

  size_t window_x = WINDOW.x;
  size_t window_y = WINDOW.y;

  double circ_rad = window_x / NUM_BODIES;
  list_t *circle_shape = make_circle(circ_rad, 0, 0);

  double circle_mass = polygon_area(circle_shape);
  rgb_color_t white = color_init(MAX_COLOR, MAX_COLOR, MAX_COLOR);
  rgb_color_t *color = malloc(sizeof(rgb_color_t));
  vector_t position = VEC_ZERO;

  if (scene_bodies(curr_scene) == 0 ||
      scene_bodies(curr_scene) == (NUM_BODIES / 2)) {
    position.x = circ_rad;
  } else {
    position = body_get_centroid(
        scene_get_body(curr_scene, scene_bodies(curr_scene) - 1));
    position.x += (circ_rad * 2);
  }

  if (scene_bodies(curr_scene) < NUM_BODIES * 0.5) {
    position.y = window_y / 2;
    *color = white;
    circle_mass = INFINITY;
  } else {
    position.y =
        -100 * sin(((scene_bodies(curr_scene) - (NUM_BODIES * 0.5)) * M_PI) /
                   QUARTER_BODIES) +
        (window_y * 0.5);
    float r = color->r = (rand() % 255) / 255.0;
    float g = color->g = (rand() % 255) / 255.0;
    float b = color->b = (rand() % 255) / 255.0;
    *color = color_init(r, g, b);
  }
  body_t *to_add = body_init(circle_shape, circle_mass, *color);
  body_set_centroid(to_add, position);

  scene_add_body(curr_scene, to_add);
}

void calculate_forces(scene_t *curr_scene) {
  for (size_t i = NUM_BODIES / 2; i < NUM_BODIES; i++) {
    body_t *mass = scene_get_body(curr_scene, i);
    body_t *anchor = scene_get_body(curr_scene, i - (NUM_BODIES / 2));
    create_spring(curr_scene, SPRING_CONST, mass, anchor);
    if (i >= (3 * (NUM_BODIES / 4)) - 1 && i < NUM_BODIES) {
      create_drag(curr_scene, DRAG_CONST, scene_get_body(curr_scene, i));
    }
  }
}

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;

  sdl_init(min, max);
  state_t *new_state = malloc(sizeof(state_t));
  scene_t *spring_damping_scene = scene_init();

  for (size_t i = 0; i < NUM_BODIES; i++) {
    populate_body_list(spring_damping_scene);
  }
  calculate_forces(spring_damping_scene);
  sdl_render_scene(spring_damping_scene);
  new_state->scene = spring_damping_scene;
  return new_state;
}

void emscripten_main(state_t *state) {
  double dt = time_since_last_tick();
  scene_t *curr_scene = state->scene;
  scene_tick(curr_scene, dt);
  sdl_render_scene(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
