#include "body.h"
#include "color.h"
#include "forces.h"
#include "list.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const vector_t CENTROID = (vector_t){.x = 250, .y = 250};

const double GRAV_CONSTANT = 500;

const size_t NUM_STAR_POINTS = 8;

const double MAX_SIZE = 10;
const size_t NUM_SCENE_BODIES = 26;

const size_t SHIFT_NUM = 15;
const size_t RAD_WIND = 40;
const size_t MAX_COLOR = 255;
const double MAX_COLOR_DECI = 255.0;

typedef struct state {
  scene_t *scene;
} state_t;

void populate_body_list(scene_t *curr_scene) {
  size_t window_x = WINDOW.x;
  size_t window_y = WINDOW.y;

  double rand_pos_x = (SHIFT_NUM + (rand() % (window_x)));
  double rand_pos_y = (SHIFT_NUM + (rand() % (window_y)));

  size_t radius = (size_t)(rand() % RAD_WIND);

  list_t *star_shape = make_star(radius, NUM_STAR_POINTS, 0, 0);

  double star_mass = polygon_area(star_shape);

  body_t *to_add =
      body_init(star_shape, star_mass,
                color_init((double)(rand() % MAX_COLOR) / MAX_COLOR_DECI,
                           (double)(rand() % MAX_COLOR) / MAX_COLOR_DECI,
                           (double)(rand() % MAX_COLOR) / MAX_COLOR_DECI));
  body_set_centroid(to_add, (vector_t){rand_pos_x, rand_pos_y});

  scene_add_body(curr_scene, to_add);
}

void calculate_force(scene_t *curr_scene) {
  for (size_t i = 0; i < NUM_SCENE_BODIES; i++) {
    for (size_t j = 0; j < NUM_SCENE_BODIES; j++) {
      if (i != j) {
        body_t *body1 = scene_get_body(curr_scene, i);
        body_t *body2 = scene_get_body(curr_scene, j);
        create_newtonian_gravity(curr_scene, GRAV_CONSTANT, body1, body2);
      }
    }
  }
}

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;
  sdl_init(min, max);
  state_t *new_state = malloc(sizeof(state_t));
  scene_t *n_bod_scene = scene_init();
  for (size_t i = 0; i < NUM_SCENE_BODIES; i++) {
    populate_body_list(n_bod_scene);
  }

  sdl_render_scene(n_bod_scene);
  calculate_force(n_bod_scene);

  new_state->scene = n_bod_scene;

  return new_state;
}

void emscripten_main(state_t *state) {
  double dt = time_since_last_tick();

  scene_t *curr_scene = state->scene;
  scene_tick(curr_scene, dt);
  sdl_render_scene(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}