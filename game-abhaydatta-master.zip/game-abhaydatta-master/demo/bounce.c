#include "body.h"
#include "color.h"
#include "list.h"
#include "polygon.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include "vector.h"
#include <assert.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const vector_t CENTROID = (vector_t){.x = 250, .y = 250};

const size_t NUM_CIRC_POINTS = 10;
const size_t STAR_LENGTH = 30;
const size_t ROT_ANGLE = 5;
const vector_t VEL_INITIAL = {100, 100};

const float YELLOW_R = 207.0 / 255.0;
const float YELLOW_G = 159.0 / 255.0;
const float YELLOW_B = 206.0 / 255.0;
const size_t NUM_SHAPES = 1;

typedef struct state {
  scene_t *scene;
} state_t;

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;
  vector_t velocity = VEL_INITIAL;
  sdl_init(min, max);

  state_t *new_state = malloc(sizeof(state_t));
  scene_t *bounce = scene_init();

  rgb_color_t *color = malloc(sizeof(rgb_color_t));
  color->r = YELLOW_R;
  color->g = YELLOW_G;
  color->b = YELLOW_B;
  list_t *shape =
      make_star(STAR_LENGTH, NUM_CIRC_POINTS, CENTROID.x, CENTROID.y);

  double mass = polygon_area(shape);
  body_t *star = body_init(shape, mass, *color);
  body_set_velocity(star, velocity);
  scene_add_body(bounce, star);
  new_state->scene = bounce;
  return new_state;
}

void star_out_of_bounds(body_t *star, vector_t distance) {

  list_t *shape = body_get_shape(star);
  for (size_t i = 0; i < list_size(shape); i++) {
    vector_t *vertex = list_get(shape, i);
    double x = vertex->x + distance.x;
    double y = vertex->y + distance.y;

    vector_t star_vel = body_get_velocity(star);

    double wind_x = WINDOW.x;
    double wind_y = WINDOW.y;
    size_t changed = 0;

    if (x <= 0) {
      body_set_velocity(star, (vector_t){star_vel.x * -1, star_vel.y});
      changed = 1;
    }
    if (y >= wind_y) {
      body_set_velocity(star, (vector_t){star_vel.x, star_vel.y * -1});
      changed = 1;
    }
    if (x >= wind_x) {
      body_set_velocity(star, (vector_t){star_vel.x * -1, star_vel.y});
      changed = 1;
    }
    if (y <= 0) {
      body_set_velocity(star, (vector_t){star_vel.x, star_vel.y * -1});
      changed = 1;
    }

    if (changed == 1) {
      break;
    }
  }
}

void emscripten_main(state_t *state) {
  double dt = time_since_last_tick();
  scene_t *curr_scene = state->scene;
  scene_tick(curr_scene, dt);
  body_t *star = scene_get_body(curr_scene, 0);
  list_t *shape = body_get_actual_shape(star);

  vector_t distance = vec_multiply(dt, body_get_velocity(star));
  polygon_translate(shape, distance);

  vector_t center = polygon_centroid(shape);
  polygon_rotate(shape, ROT_ANGLE, center);

  star_out_of_bounds(star, distance);
  sdl_render_scene(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
