#include "forces.h"
#include "polygon.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};

const rgb_color_t COLORS[] = {
    (rgb_color_t){0.6, 0, 0},   (rgb_color_t){1.0, 0, 0},
    (rgb_color_t){1.0, 0.5, 0}, (rgb_color_t){0.97, 0.82, 0.08},
    (rgb_color_t){1.0, 1.0, 0}, (rgb_color_t){0, 1.0, 0},
    (rgb_color_t){0, 0.4, 0},   (rgb_color_t){0, 0.5, 1.0},
    (rgb_color_t){0, 0, 1},     (rgb_color_t){0.5, 0, 1.0}};

const rgb_color_t BLACK = (rgb_color_t){0, 0, 0};

const size_t NUM_COLS_BRICKS = 10;
const size_t NUM_ROWS_BRICKS = 3;
const size_t GAP_SPACE = 5;

const size_t RECT_LENGTH = 94;
const size_t RECT_WIDTH = 15;

const size_t HALF_RECT_LENGTH = RECT_LENGTH / 2;
const size_t HALF_RECT_WIDTH = RECT_WIDTH / 2;

const size_t BALL_RAD = 10;

const double WALL_WIDTH = 10;

const size_t PROJECTILE_POINTS_MASS = 10;
const size_t PROJECTILE_LENGTH = 15;

const size_t RECT_MASS = INFINITY;
const size_t BALL_MASS = 5;

const vector_t PLAYER_VELOCITY = (vector_t){.x = 150, .y = 0};
const vector_t BALL_VELOCITY = (vector_t){.x = 100, .y = 100};
const vector_t PROJECTILE_VELOCITY = (vector_t){.x = 0, .y = -100};

const double WALL_ELASTICITY = 1;
const double BRICK_ELASTICITY = 1;
const double PLAYER_ELASTICITY = 1;

const vector_t PLAYER_CENTROID = (vector_t){.x = 250, .y = 20};

const size_t SPAWN_WAIT_TIME = 1000;

const double HALF_PI = 0.5 * M_PI;
const double THREE_HALF_PI = 3.0 * HALF_PI;

typedef struct state {
  scene_t *scene;
} state_t;

void populate_player(scene_t *curr_scene) {
  list_t *player_shape = make_rectangle(RECT_LENGTH, RECT_WIDTH,
                                        PLAYER_CENTROID.x, PLAYER_CENTROID.y);
  body_t *player =
      body_init_with_info(player_shape, RECT_MASS, COLORS[1], "Player", NULL);
  body_set_centroid(player, PLAYER_CENTROID);
  body_set_rotation(player, THREE_HALF_PI);
  scene_add_body(curr_scene, player);
}

void populate_ball(scene_t *curr_scene) {
  list_t *ball_shape =
      make_circle(BALL_RAD, PLAYER_CENTROID.x,
                  PLAYER_CENTROID.y + HALF_RECT_WIDTH + BALL_RAD);
  body_t *ball =
      body_init_with_info(ball_shape, BALL_MASS, COLORS[1], "Ball", NULL);
  body_set_centroid(ball, (vector_t){WINDOW.x / 2, WINDOW.y / 2});
  body_set_velocity(ball, BALL_VELOCITY);
  scene_add_body(curr_scene, ball);
  create_physics_collision(curr_scene, PLAYER_ELASTICITY, ball,
                           scene_get_body(curr_scene, 0));
}

void populate_bricks(scene_t *curr_scene) {
  size_t center_x = GAP_SPACE + HALF_RECT_LENGTH;
  size_t center_y = WINDOW.y - GAP_SPACE;

  body_t *ball = scene_get_body(curr_scene, 1);

  for (size_t i = 0; i < NUM_COLS_BRICKS; i++) {
    for (size_t j = 0; j < NUM_ROWS_BRICKS; j++) {
      list_t *brick =
          make_rectangle(RECT_LENGTH, RECT_WIDTH, center_x, center_y);

      body_t *to_add =
          body_init_with_info(brick, INFINITY, COLORS[i], "Brick", NULL);
      body_set_centroid(to_add, (vector_t){center_x, center_y});
      body_set_rotation(to_add, THREE_HALF_PI);

      scene_add_body(curr_scene, to_add);

      center_y -= (GAP_SPACE + RECT_WIDTH);

      create_physics_collision(curr_scene, BRICK_ELASTICITY, ball, to_add);
      create_one_destructive_collision(curr_scene, ball, to_add);
    }
    center_x += (GAP_SPACE + RECT_LENGTH);
    center_y = WINDOW.y - GAP_SPACE;
  }
}

void populate_brick_projectile(scene_t *curr_scene, body_t *brick) {
  list_t *projectile_shape =
      make_star(PROJECTILE_LENGTH, PROJECTILE_POINTS_MASS,
                body_get_centroid(brick).x, body_get_centroid(brick).y);

  rgb_color_t color_match = body_get_color(brick);

  body_t *projectile =
      body_init_with_info(projectile_shape, PROJECTILE_POINTS_MASS, color_match,
                          "Brick Projectile", NULL);
  body_set_centroid(projectile, body_get_centroid(brick));
  body_set_velocity(projectile, PROJECTILE_VELOCITY);
  scene_add_body(curr_scene, projectile);

  body_t *player = scene_get_body(curr_scene, 0);
  create_destructive_collision(curr_scene, player, projectile);
}

void populate_walls(scene_t *curr_scene) {
  list_t *wall_shape1 = make_rectangle(WINDOW.y, WALL_WIDTH, 0, WINDOW.y / 2);
  body_t *wall1 =
      body_init_with_info(wall_shape1, INFINITY, BLACK, "Wall", NULL);
  body_set_centroid(wall1, (vector_t){0, WINDOW.y / 2});

  list_t *wall_shape2 =
      make_rectangle(WINDOW.y, WALL_WIDTH, WINDOW.x, WINDOW.y / 2);
  body_t *wall2 =
      body_init_with_info(wall_shape2, INFINITY, BLACK, "Wall", NULL);
  body_set_centroid(wall2, (vector_t){WINDOW.x, WINDOW.y / 2});

  scene_add_body(curr_scene, wall1);
  scene_add_body(curr_scene, wall2);
  create_physics_collision(curr_scene, WALL_ELASTICITY,
                           scene_get_body(curr_scene, 1), wall1);
  create_physics_collision(curr_scene, WALL_ELASTICITY,
                           scene_get_body(curr_scene, 1), wall2);
}

void populate_scene_init(scene_t *curr_scene) {
  // player at index 0
  populate_player(curr_scene);

  // ball at index 1
  populate_ball(curr_scene);

  // walls at indices 2 and 3
  populate_walls(curr_scene);

  // bricks at indices 4+
  populate_bricks(curr_scene);
}

void on_key(char key, key_event_type_t type, double held_time, state_t *state) {
  scene_t *scene = state->scene;
  body_t *player = scene_get_body(scene, 0);
  if (type == KEY_PRESSED) {
    switch (key) {
    case LEFT_ARROW:
      body_set_velocity(player, vec_negate(PLAYER_VELOCITY));
      break;
    case RIGHT_ARROW:
      body_set_velocity(player, PLAYER_VELOCITY);
      break;
    }
  } else if (type == KEY_RELEASED) {
    body_set_velocity(player, VEC_ZERO);
  }
}

void spawn_brick_projectile(scene_t *curr_scene) {
  set_tot(curr_scene, get_tot(curr_scene) + 1);

  if ((size_t)(get_tot(curr_scene) + SPAWN_WAIT_TIME) % SPAWN_WAIT_TIME == 0) {
    body_t *player = scene_get_body(curr_scene, 0);
    size_t player_x = body_get_centroid(player).x;

    body_t *closest_body = scene_get_body(curr_scene, 4);

    for (size_t i = 2; i < scene_bodies(curr_scene); i++) {
      body_t *curr_body = scene_get_body(curr_scene, i);

      if (strcmp(body_get_info(curr_body), "Brick") == 0) {
        if (closest_body == NULL) {
          closest_body = curr_body;
        } else {
          size_t curr_x = body_get_centroid(curr_body).x;
          size_t closest_x = body_get_centroid(closest_body).x;

          if (curr_x - player_x <= closest_x - player_x) {
            closest_body = curr_body;
          }
        }
      }
    }
    populate_brick_projectile(curr_scene, closest_body);
  }
}

void wrap_around(scene_t *curr_scene) {
  body_t *player = scene_get_body(curr_scene, 0);
  vector_t player_center = body_get_centroid(player);

  if ((player_center.x + HALF_RECT_LENGTH) >= WINDOW.x) {
    body_set_velocity(player, vec_negate(PLAYER_VELOCITY));
  } else if ((player_center.x - HALF_RECT_LENGTH) <= 0) {
    body_set_velocity(player, PLAYER_VELOCITY);
  }
}

bool check_out_of_bounds(scene_t *curr_scene) {
  body_t *ball = scene_get_body(curr_scene, 1);
  // if the ball is at the bottom of the frame or the top
  return ((body_get_centroid(ball).y <= BALL_RAD) ||
          (body_get_centroid(ball).y >= (WINDOW.y - BALL_RAD)));
}

bool player_shot(scene_t *curr_scene) {
  body_t *first = scene_get_body(curr_scene, 0);
  if (strcmp(body_get_info(first), "Player") != 0) {
    return 1;
  }
  return 0;
}

bool cleared_bricks(scene_t *curr_scene) {
  size_t counter = 0;
  for (size_t i = 0; i < scene_bodies(curr_scene); i++) {
    body_t *curr_body = scene_get_body(curr_scene, i);
    if (strcmp(body_get_info(curr_body), "Brick") == 0) {
      counter++;
      return 0;
    }
  }
  return 1;
}

void restart(scene_t *scene) {
  double dt = time_since_last_tick();
  for (size_t i = 0; i < scene_bodies(scene); i++) {
    body_remove(scene_get_body(scene, i));
  }
  scene_tick(scene, dt);
  populate_scene_init(scene);
}

state_t *emscripten_init() {
  scene_t *breakout_scene = scene_init();
  sdl_init(VEC_ZERO, WINDOW);
  sdl_on_key((void *)on_key);
  state_t *new_state = malloc(sizeof(state_t));
  new_state->scene = breakout_scene;
  restart(breakout_scene);
  return new_state;
}

bool check_end(scene_t *curr_scene) {
  return (player_shot(curr_scene) || cleared_bricks(curr_scene) ||
          check_out_of_bounds(curr_scene));
}

void emscripten_main(state_t *state) {
  double dt = time_since_last_tick();
  scene_t *curr_scene = state->scene;
  scene_tick(curr_scene, dt);
  wrap_around(curr_scene);
  if (check_end(curr_scene)) {
    restart(curr_scene);
  }
  sdl_render_scene(curr_scene);
  spawn_brick_projectile(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
