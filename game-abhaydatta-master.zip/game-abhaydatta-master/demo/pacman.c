#include "body.h"
#include "color.h"
#include "list.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const vector_t CENTROID = (vector_t){.x = 250, .y = 250};

const double HALF_PI = 0.5 * M_PI;
const double THREE_HALF_PI = 3.0 * HALF_PI;

const size_t NUM_CIRC_POINTS = 10;
const vector_t VEL_INITIAL = {100, 100};
const double RADIUS_RATIO = 0.5;

const size_t RADIUS_PAC = 30;
const size_t RADIUS_PEL = 10;
const size_t NUM_SCENE_BODIES = 25;

const double ACCELERATION = 100.0;
const size_t SPAWN_WAIT_TIME = 5;

const rgb_color_t YELLOW = {0.99, 0.80, 0};

typedef struct state {
  scene_t *scene;
} state_t;

void populate_body_list(scene_t *curr_scene) {

  size_t window_x = WINDOW.x;
  size_t window_y = WINDOW.y;

  double rand_pos_x = (1 + (rand() % (window_x)));
  double rand_pos_y = (1 + (rand() % (window_y)));

  list_t *pel_shape = make_circle(RADIUS_PEL, 0, 0);

  double pel_mass = 1.0;
  body_t *to_add = body_init(pel_shape, pel_mass, YELLOW);

  body_set_centroid(to_add, (vector_t){rand_pos_x, rand_pos_y});

  scene_add_body(curr_scene, to_add);
}

void populate_pacman_init(scene_t *curr_scene) {
  list_t *shape = make_pacman(RADIUS_PAC, 0, 0);
  double mass = M_PI * pow(RADIUS_PAC, 2);
  body_t *pacman = body_init(shape, mass, YELLOW);
  body_set_centroid(pacman, CENTROID);
  scene_add_body(curr_scene, pacman);

  for (size_t i = 1; i < NUM_SCENE_BODIES; i++) {
    populate_body_list(curr_scene);
  }
}

void on_key(char key, key_event_type_t type, double held_time, state_t *state) {
  scene_t *scene = state->scene;
  body_t *body = scene_get_body(scene, 0);
  vector_t curr_velocity = body_get_velocity(body);
  double acc_vel = held_time * ACCELERATION;

  if (type == KEY_PRESSED) {
    switch (key) {
    case DOWN_ARROW:
      body_set_velocity(body,
                        (vec_add(curr_velocity, (vector_t){0, -acc_vel})));
      body_set_rotation(body, THREE_HALF_PI);
      break;

    case UP_ARROW:
      body_set_velocity(body, (vec_add(curr_velocity, (vector_t){0, acc_vel})));
      body_set_rotation(body, HALF_PI);
      break;

    case LEFT_ARROW:
      body_set_velocity(body,
                        (vec_subtract(curr_velocity, (vector_t){acc_vel, 0})));
      body_set_rotation(body, M_PI);
      break;

    case RIGHT_ARROW:
      body_set_velocity(body, (vec_add(curr_velocity, (vector_t){acc_vel, 0})));
      body_set_rotation(body, 0);
      break;
    }
  } else if (type == KEY_RELEASED) {
    body_set_velocity(body, VEC_ZERO);
  }
}

void eat_pellet(scene_t *curr_scene) {
  body_t *pac = scene_get_body(curr_scene, 0);
  vector_t pac_centroid = body_get_centroid(pac);

  for (size_t i = 1; i < scene_bodies(curr_scene); i++) {
    if (scene_get_body(curr_scene, i) != NULL) {
      body_t *pellet = scene_get_body(curr_scene, i);
      vector_t pel_center = body_get_centroid(pellet);
      vector_t distance = vec_subtract(pac_centroid, pel_center);

      double dist = pow((pow(distance.x, 2) + pow(distance.y, 2)), 0.5);
      if (dist <= RADIUS_RATIO * RADIUS_PAC) {
        double new_mass = body_get_mass(pac) + body_get_mass(pellet);
        body_set_mass(pac, new_mass);
        list_t *scene_bodies = get_scene_list(curr_scene);
        body_free(list_remove(scene_bodies, i));
        i--;
      }
    }
  }
}

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;

  sdl_on_key((void *)on_key);
  state_t *new_state = malloc(sizeof(state_t));

  sdl_init(min, max);
  scene_t *pacman_scene = scene_init();

  populate_pacman_init(pacman_scene);

  sdl_render_scene(pacman_scene);

  new_state->scene = pacman_scene;

  return new_state;
}

void wrap_around(scene_t *curr_scene) {
  body_t *pac = scene_get_body(curr_scene, 0);
  vector_t center = body_get_centroid(pac);

  if ((center.x + RADIUS_PAC) >= WINDOW.x) {
    body_set_centroid(pac, (vector_t){RADIUS_PAC, center.y});
  }
  if ((center.x - RADIUS_PAC) <= 0) {
    body_set_centroid(pac, (vector_t){WINDOW.x - RADIUS_PAC, center.y});
  }
  if ((center.y + RADIUS_PAC) >= WINDOW.y) {
    body_set_centroid(pac, (vector_t){center.x, RADIUS_PAC});
  }
  if ((center.y - RADIUS_PAC) <= 0) {
    body_set_centroid(pac, (vector_t){center.x, WINDOW.y - RADIUS_PAC});
  }
}

void spawn_pellet(scene_t *curr_scene) {
  double dt = time_since_last_tick();
  set_tot(curr_scene, get_tot(curr_scene) + dt);

  if ((size_t)get_tot(curr_scene) % SPAWN_WAIT_TIME >= 4) {
    populate_body_list(curr_scene);
    set_tot(curr_scene, 0.0);
  }
}

void emscripten_main(state_t *state) {
  scene_t *curr_scene = state->scene;
  double dt = time_since_last_tick();

  scene_tick(curr_scene, dt);
  eat_pellet(curr_scene);
  wrap_around(curr_scene);
  sdl_render_scene(curr_scene);
  spawn_pellet(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
