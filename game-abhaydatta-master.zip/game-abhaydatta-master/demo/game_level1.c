#include "collision.h"
#include "forces.h"
#include "polygon.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include <emscripten.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// const vector_t INIT_VELOCITY = (vector_t){300, 100};
const double GRAVITY1 = 150;
const double GRAVITY2 = 90;
const double NUM_BONES = 36;
const double NUM_PINEAPPLES = 1;

const double MARKER_LENGTH = 5;
const double MARKER_VERTICES = 10;

const rgb_color_t PINEAPPLE_COLOR = (rgb_color_t){1.0, 0.75, 0.75};
const rgb_color_t BONE_COLOR = (rgb_color_t){1.0, 0.0, 0.0};
const rgb_color_t MARKER_COLOR = {0.0, 0.0, 0.0};
const rgb_color_t HOPPER_COLOR = {0.5, 0.5, 0.5};

// const rgb_color_t BLACK = (rgb_color_t){0.0, 0.0, 0.0};

const size_t BONE_MASS = 5;
const size_t PINEAPPLE_MASS = 10;

const size_t BONE_SCORE = 10.0;
const size_t GOLDEN_BONE_SCORE = 20.0;
const size_t PINEAPPLE_SCORE = 100.0;
const size_t PORTAL_SCORE = 200.0;

const double GROUND_CR = 1.0;
const double WALL_WIDTH = 10.0;

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};
const double HALF_MULTIPLY = 0.5;

const vector_t PORTAL_DIMENSIONS = (vector_t){.x = 100, .y = 20};
const vector_t PORTAL_VELOCITY = (vector_t){.x = 0, .y = 100};
const size_t PORTAL_IDX = 1;
const size_t PINEAPPLE_IDX = 2;

const rgb_color_t RED = {1.0, 0.0, 0.0};
const rgb_color_t WHITE = {1.0, 1.0, 1.0};
const rgb_color_t BLACK = {0.0, 0.0, 0.0};
const double WALL_ELASTICITY = 1;

const vector_t HOPPER_SIZE = (vector_t){100, 50};
const vector_t HOPPER_VELOCITY = (vector_t){.x = 300, .y = 100};

const vector_t BONE_SIZE = (vector_t){.x = 15, .y = 10};
const vector_t PINEAPPLE_SIZE = (vector_t){.x = 15, .y = 20};

// Level 1: “Super Hopper at Red Door”
// The player starts off with 3 Hoppers, i.e., 3 chances
// They can use the UP and DOWN arrows to choose the height at which they want
// to be launched, but the gravitational acceleration is kept constant They can
// press the SPACE bar to launch the Hoppers There will be some bones at
// different locations on the screen (in projectile patterns), so they can
// choose which height to launch at, to collect as many bones as possible The
// end goal is to enter the portal that is at the other end of the screen – but
// the portal is moving up and down (although in a predictable manner), so they
// have to factor that in when they are launching their Hopper As soon as one
// Hopper makes it through the portal, the player can move to next level There
// is also a pineapple on screen, in a path that is not the optimal bone path,
// so the player would have to have the foresight to sacrifice one of their
// Hoppers to get the pineapple The pineapple activates a power-up that shows
// the optimal projectile path (with the most number of bones) to the player If
// none of the Hoppers make it through the portal, the player loses, and they
// are taken to the end screen that displays their points

// Shrishti:
// Calculating where the different types of bones and pineapples must be
// accessible locations throughout the game Implementing forces: gravity,
// one-sided collision

// Sophie:
// Designing Hopper pineapples, bones
// Designing background for level 1
// Detecting the moving portal on level 1
// Creating the transitions between levels as Hopper achieves each level
// Restarting the game/
// redirecting to end page if player loses this level

// Sanvi:
// Key movement for level 1: → UP/DOWN to choose height of launch
// SPACE to launch - Keeping track of player’s score with text feature

// Evelyn:
// Implementing one-sided destructive collisions for the portal in level 1
// Implementing one-sided destructive collisions for eating the bones in level 1

// calculates the positions that the bones need to spawn at
// needs to be used when we populate the bones into the scene

// DEFINING STATE

typedef struct state {
  scene_t *scene;
  bool level_passed;
  size_t hoppers_left;
  bool projectile;
  double score;
  // should we add hopper to the state??
} state_t;

// CREATING PATH AND PROJECTILE MOTION
// makes hopper travel in projectile motion
void projectile_motion(state_t *state, double dt) {
  body_t *body = scene_get_body(state->scene, 0);
  list_t *vertices = body_get_shape(body);
  vector_t distance = vec_multiply(dt, body_get_velocity(body));
  vector_t curr_vel = body_get_velocity(body);
  for (size_t i = 0; i < list_size(vertices); i++) {
    vector_t *vector = list_get(vertices, i);
    double y = vector->y + distance.y;
    if (y <= 0) {
      state->hoppers_left = state->hoppers_left - 1;
      if (state->hoppers_left == 0) {
        // end game
        emscripten_force_exit(0);
      }
      body_set_velocity(body, VEC_ZERO);
      body_set_centroid(body, (vector_t){HOPPER_SIZE.x * HALF_MULTIPLY,
                                         HOPPER_SIZE.y * HALF_MULTIPLY});
      state->projectile = false;
      break;
    } else {
      body_set_velocity(body,
                        (vector_t){curr_vel.x, (curr_vel.y - GRAVITY2 * dt)});
    }
  }
}

void add_score(state_t *state, body_t *player, body_t *collided_body) {
  list_t *player_shape = body_get_actual_shape(player);
  list_t *collided_shape = body_get_actual_shape(collided_body);
  if (get_collision_bool(find_collision(player_shape, collided_shape))) {
    state->score = state->score + body_get_score(collided_body);
  }
}

// if the pineapple is consumed, then call this function
void show_best_path(list_t *pos_list, scene_t *scene) {
  // body_t *hopper = scene_get_body(scene, 0);
  for (size_t i = 0; i < list_size(pos_list); i++) {
    list_t *shape = make_star(MARKER_LENGTH, MARKER_VERTICES,
                              ((vector_t *)list_get(pos_list, i))->x,
                              ((vector_t *)list_get(pos_list, i))->y);
    body_t *marker =
        body_init_with_info(shape, 1, MARKER_COLOR, "Marker", NULL);
    scene_add_body(scene, marker);
    // create_one_destructive_collision(scene, hopper, marker);
  }
}

// CALCULATING BODY POSITIONS
list_t *calculate_bone_positions_1(scene_t *scene) {
  list_t *pos_list = list_init(1, free);
  double dt = 1.0;
  for (size_t i = 0; i < NUM_BONES / 4; i++) {
    vector_t *s = malloc(sizeof(vector_t));
    s->y = (HOPPER_VELOCITY.y * dt) - (0.5 * GRAVITY1 * dt);
    s->x = (HOPPER_VELOCITY.x * dt);
    dt++;
    list_add(pos_list, s);
  }
  return pos_list;
}

list_t *calculate_bone_positions_2(scene_t *scene) {
  list_t *pos_list = list_init(1, free);
  double dt = 0.0;
  for (size_t i = 0; i < NUM_BONES / 4; i++) {
    vector_t *s = malloc(sizeof(vector_t));
    s->y = WINDOW.y / 2 + (HOPPER_VELOCITY.y * dt) - (0.5 * GRAVITY2 * dt * dt);
    s->x = (HOPPER_VELOCITY.x * dt);
    dt += 0.5;
    list_add(pos_list, s);
  }
  return pos_list;
}

// add a few random ones too
list_t *calculate_bone_positions_3(scene_t *scene) {
  list_t *pos_list = list_init(1, free);
  for (size_t i = 0; i < NUM_BONES / 2; i++) {
    vector_t *s = malloc(sizeof(vector_t));
    *s = (vector_t){(rand() % (size_t)WINDOW.x), (rand() % (size_t)WINDOW.y)};
    list_add(pos_list, s);
  }
  return pos_list;
}

vector_t calculate_pineapple_position(scene_t *scene) {
  time_t t;
  srand((unsigned)time(&t));
  return (vector_t){(rand() % (int)WINDOW.x / 2), (rand() % (int)WINDOW.y / 2)};
}

// MAKE BODY SHAPES
// TODO: these shapes will just be the fundamental shapes that we can overlay
// the sprite on so it could also just be rectangels if required
list_t *make_bone_shape() {
  return make_rectangle(BONE_SIZE.y, BONE_SIZE.y, 0, 0);
}

list_t *make_pineapple_shape() {
  return make_rectangle(PINEAPPLE_SIZE.y, PINEAPPLE_SIZE.x, 0, 0);
}

list_t *make_hopper_shape() {
  return make_rectangle(HOPPER_SIZE.y, HOPPER_SIZE.x,
                        HOPPER_SIZE.x * HALF_MULTIPLY,
                        HOPPER_SIZE.y * HALF_MULTIPLY);
}

list_t *make_portal_shape() {
  return make_rectangle(PORTAL_DIMENSIONS.x, PORTAL_DIMENSIONS.y,
                        WINDOW.x - PORTAL_DIMENSIONS.y * HALF_MULTIPLY,
                        WINDOW.y * HALF_MULTIPLY);
}

// POPULATING BODIES FUNCTIONS
void populate_bones_list(scene_t *scene, size_t num_bones) {
  list_t *positions = list_init(3, NULL);
  list_add(positions, calculate_bone_positions_1(scene));
  list_add(positions, calculate_bone_positions_2(scene));
  list_add(positions, calculate_bone_positions_3(scene));

  positions = list_merge(positions);

  body_t *hopper = scene_get_body(scene, 0);
  // for (size_t i = 0; i < num_bones; i++) {
  for (size_t i = 0; i < list_size(positions); i++) {
    list_t *bone_shape = make_bone_shape();
    body_t *bone =
        body_init_with_info(bone_shape, BONE_MASS, BONE_COLOR, "Bone", NULL);
    if (i > list_size(positions) / 2) {
      body_set_score(bone, GOLDEN_BONE_SCORE);
    } else {
      body_set_score(bone, BONE_SCORE);
    }
    body_set_centroid(bone, *(vector_t *)list_get(positions, i));
    scene_add_body(scene, bone);
    create_one_destructive_collision(scene, hopper, bone);
  }
  free(positions);
}

void populate_pineapple_list(scene_t *scene, size_t num_pineapples) {
  // implement one-sided collision
  body_t *hopper = scene_get_body(scene, 0);
  for (size_t i = 0; i < num_pineapples; i++) {
    vector_t pineapple_position = calculate_pineapple_position(scene);
    list_t *pineapple_shape = make_pineapple_shape();
    body_t *pineapple = body_init_with_info(pineapple_shape, PINEAPPLE_MASS,
                                            PINEAPPLE_COLOR, "Pineapple", NULL);
    body_set_centroid(pineapple, pineapple_position);
    body_set_score(pineapple, PINEAPPLE_SCORE);
    scene_add_body(scene, pineapple);
    create_one_destructive_collision(scene, hopper, pineapple);
  }
}

void populate_portal(scene_t *scene) {
  list_t *portal = make_portal_shape();

  body_t *to_add = body_init_with_info(portal, INFINITY, RED, "Portal", NULL);
  body_set_centroid(to_add,
                    (vector_t){WINDOW.x - PORTAL_DIMENSIONS.y * HALF_MULTIPLY,
                               WINDOW.y * HALF_MULTIPLY});
  body_set_velocity(to_add, PORTAL_VELOCITY);
  body_set_score(to_add, PORTAL_SCORE);
  scene_add_body(scene, to_add);
  body_t *hopper = scene_get_body(scene, 0);
  create_one_destructive_collision(scene, hopper, to_add);
}

void populate_hopper(scene_t *scene) {
  // add hopper to scene bodies
  // needs to add it three times
  list_t *hopper_shape = make_hopper_shape();
  body_t *hopper = body_init_with_info(hopper_shape, PINEAPPLE_MASS,
                                       HOPPER_COLOR, "Pineapple", NULL);
  body_set_score(hopper, 10.0);
  scene_add_body(scene, hopper);
}

// PORTAL MOTION
void portal_motion(scene_t *scene) {
  body_t *portal = scene_get_body(scene, PORTAL_IDX);
  if (body_get_centroid(portal).y + (PORTAL_DIMENSIONS.x * HALF_MULTIPLY) >=
          WINDOW.y ||
      body_get_centroid(portal).y - (PORTAL_DIMENSIONS.x * HALF_MULTIPLY) <=
          0) {
    vector_t new_vel = vec_negate(body_get_velocity(portal));
    body_set_velocity(portal, new_vel);
  }
}

// POPULATING SCENE INIT
void populate_scene_init(scene_t *curr_scene) {
  // player at index 0
  populate_hopper(curr_scene);

  // portal at index 1
  populate_portal(curr_scene);

  // pineapple at index 2
  populate_pineapple_list(curr_scene, NUM_PINEAPPLES);

  // bones at index 3 onwards
  populate_bones_list(curr_scene, NUM_BONES);
}

void on_key(char key, key_event_type_t type, double held_time, state_t *state) {
  scene_t *scene = state->scene;
  body_t *player = scene_get_body(scene, 0);
  if (type == KEY_PRESSED) {
    switch (key) {
    case DOWN_ARROW:
      body_set_velocity(player, (vector_t){0, -HOPPER_VELOCITY.y});
      break;
    case UP_ARROW:
      body_set_velocity(player, (vector_t){0, HOPPER_VELOCITY.y});
      break;
    case SPACE:
      if (state->projectile == false) {
        body_set_velocity(player, HOPPER_VELOCITY);
        state->projectile = true;
      }
    }
  } else if (type == KEY_RELEASED) {
    body_set_velocity(player, VEC_ZERO);
  }
}

state_t *emscripten_init() {
  scene_t *level1_scene = scene_init();
  sdl_init(VEC_ZERO, WINDOW);
  state_t *new_state = malloc(sizeof(state_t));
  new_state->scene = level1_scene;
  populate_scene_init(level1_scene);
  new_state->level_passed = false;
  new_state->hoppers_left = 3;
  new_state->score = 10.0;
  new_state->projectile = false;
  sdl_on_key((void *)on_key);
  return new_state;
}

bool check_pass(state_t *state) {
  scene_t *curr_scene = state->scene;
  body_t *hopper = scene_get_body(curr_scene, 0);
  list_t *hopper_shape = body_get_actual_shape(hopper);
  body_t *portal = scene_get_body(curr_scene, PORTAL_IDX);
  list_t *portal_shape = body_get_actual_shape(portal);
  if (get_collision_bool(find_collision(hopper_shape, portal_shape)) == 1) {
    state->level_passed = 1;
  } else {
    state->level_passed = 0;
  }
  return state->level_passed;
}

void display_score() {
  // display hopper score on the screen
}

void wrap_around(scene_t *scene) {
  body_t *hopper = scene_get_body(scene, 0);
  if (body_get_centroid(hopper).y >
      (WINDOW.y - HOPPER_SIZE.y * HALF_MULTIPLY)) {
    body_set_centroid(hopper, (vector_t){HOPPER_SIZE.x * HALF_MULTIPLY,
                                         HOPPER_SIZE.y * HALF_MULTIPLY});
  } else if (body_get_centroid(hopper).y < (HOPPER_SIZE.y * HALF_MULTIPLY)) {
    body_set_centroid(hopper,
                      (vector_t){HOPPER_SIZE.x * HALF_MULTIPLY,
                                 (WINDOW.y - (HOPPER_SIZE.y * HALF_MULTIPLY))});
  }
}

void emscripten_main(state_t *state) {
  // emscripten_log(EM_LOG_NO_PATHS, "num bones: %zu",
  // scene_bodies(state->scene));

  double dt = time_since_last_tick();
  scene_t *curr_scene = state->scene;
  body_t *hopper = scene_get_body(curr_scene, 0);

  emscripten_log(EM_LOG_NO_PATHS, "score: %f", state->score);

  body_t *pineapple = scene_get_body(curr_scene, PINEAPPLE_IDX);
  scene_tick(curr_scene, dt);
  if (check_pass(state)) {
    // transition to new level
    emscripten_force_exit(0);
  }
  wrap_around(curr_scene);
  emscripten_log(EM_LOG_NO_PATHS, "num hoppers: %zu", state->hoppers_left);

  collision_info_t coll = find_collision(body_get_actual_shape(hopper),
                                         body_get_actual_shape(pineapple));
  if (get_collision_bool(coll)) {
    show_best_path(calculate_bone_positions_2(curr_scene), curr_scene);
  }
  // projectile_motion(curr_scene, dt);

  // loops through all that hopper can destructively collide with, and adds the
  // scores to the state
  for (size_t i = 1; i < scene_bodies(curr_scene); i++) {
    add_score(state, hopper, scene_get_body(curr_scene, i));
  }

  if (state->projectile == true) {
    projectile_motion(state, dt);
  }
  portal_motion(curr_scene);
  sdl_render_scene(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
