#include "body.h"
#include "color.h"
#include "forces.h"
#include "list.h"
#include "scene.h"
#include "sdl_wrapper.h"
#include "shape.h"
#include "state.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

const vector_t WINDOW = (vector_t){.x = 1000, .y = 500};

const size_t BEAM_LENGTH = 25;
const size_t BEAM_WIDTH = 10;
const double SPACING = 1.5;

const size_t HALF_BEAM_LENGTH = BEAM_LENGTH / 2;
const size_t HALF_BEAM_WIDTH = BEAM_WIDTH / 2;

const size_t HERO_SEMI_MINOR = 10;
const size_t HERO_SEMI_MAJOR = 20;

const size_t ENEMY_RAD = 45;
const size_t ENEMY_DIAMETER = ENEMY_RAD * 2;
const double ROT_ANGLE = 245.0;

const double BEAM_MASS = 1;
const double ENEMY_MASS = 4;

const size_t NUM_FIXED_BODIES = 25;

const rgb_color_t GREEN = {0, 1, 0};
const rgb_color_t GRAY = {0.38, 0.38, 0.38};

const size_t SPAWN_WAIT_TIME = 100;
const size_t X_VELOCITY = 150;

const vector_t ENEMY_VELOCITY = {60, 0};
const vector_t BEAM_VELOCITY = {0, 100};

const size_t NUM_COLUMN_ENEMIES = 2;
const size_t NUM_ROW_ENEMIES = 8;

const double HALF_PI = 0.5 * M_PI;
const double THREE_HALF_PI = 3.0 * HALF_PI;

const size_t NUM_POINTS_CIRC = 20;
const size_t NUM_POINTS_PAC = 12;
const size_t NUM_POINTS_RECT = 4;

const double DEFAULT_ANGLE = 0.0;

typedef struct state {
  scene_t *scene;
} state_t;

list_t *make_invaders(size_t length, size_t center_x, size_t center_y) {
  double curr_angle = DEFAULT_ANGLE;
  double vert_angle = 2.0 * M_PI / NUM_POINTS_CIRC;
  double x = 0.0;
  double y = 0.0;
  list_t *vertices = list_init(NUM_POINTS_CIRC, (free_func_t)free);
  assert(vertices != NULL);
  for (size_t i = 0; i < NUM_POINTS_PAC; i++) {
    x = cos(curr_angle) + center_x;
    y = sin(curr_angle) + center_y;
    vector_t *vertex = malloc(sizeof(vector_t));
    vertex->x = x;
    vertex->y = y;
    list_add(vertices, vertex);
    curr_angle += vert_angle;
  }
  for (size_t i = 0; i < NUM_POINTS_CIRC - NUM_POINTS_PAC; i++) {
    x = cos(curr_angle) * length + center_x;
    y = sin(curr_angle) * length + center_y;
    vector_t *vertex = malloc(sizeof(vector_t));
    vertex->x = x;
    vertex->y = y;
    list_add(vertices, vertex);
    curr_angle += vert_angle;
  }
  return vertices;
}

list_t *make_player(size_t center_x, size_t center_y, size_t minor,
                    size_t major) {
  double curr_angle = DEFAULT_ANGLE;
  double vert_angle = 2.0 * M_PI / NUM_POINTS_CIRC;
  double x;
  double y;
  list_t *vertices = list_init(NUM_POINTS_CIRC, (free_func_t)free);
  assert(vertices != NULL);
  for (size_t i = 0; i < NUM_POINTS_CIRC; i++) {
    x = cos(curr_angle) * minor + center_x;
    y = sin(curr_angle) * major + center_y;
    vector_t *vec_ptr = malloc(sizeof(vector_t));
    vec_ptr->x = x;
    vec_ptr->y = y;
    list_add(vertices, vec_ptr);
    curr_angle += vert_angle;
  }
  return vertices;
}

list_t *make_beam(size_t length, size_t width, size_t center_x,
                  size_t center_y) {
  list_t *vertices = list_init(NUM_POINTS_RECT, (free_func_t)free);
  assert(vertices != NULL);

  double x;
  double y;

  // Top Left Vertex
  vector_t *top_left = malloc(sizeof(vector_t));
  x = center_x - (width * 0.5);
  y = center_y + (length * 0.5);
  top_left->x = x;
  top_left->y = y;
  list_add(vertices, top_left);

  // Top Right Vertex
  vector_t *top_right = malloc(sizeof(vector_t));
  x = center_x + (width * 0.5);
  top_right->x = x;
  top_right->y = y;
  list_add(vertices, top_right);

  // Bottom Right Vertex
  vector_t *bottom_right = malloc(sizeof(vector_t));
  y = center_y - (length * 0.5);
  bottom_right->x = x;
  bottom_right->y = y;
  list_add(vertices, bottom_right);

  // Bottom Left Vertex
  vector_t *bottom_left = malloc(sizeof(vector_t));
  x = center_x - (width * 0.5);
  bottom_left->x = x;
  bottom_left->y = y;
  list_add(vertices, bottom_left);

  return vertices;
}

void populate_hero_beam(scene_t *curr_scene, rgb_color_t color, char *info,
                        size_t center_x, size_t center_y) {
  list_t *beam_shape = make_beam(BEAM_LENGTH, BEAM_WIDTH, center_x, center_y);

  body_t *hero_beam = body_init_with_info(beam_shape, BEAM_MASS, color,
                                          "Hero Beam", (free_func_t)free);
  body_set_centroid(hero_beam, (vector_t){center_x, center_y});
  body_set_velocity(hero_beam, BEAM_VELOCITY);
  scene_add_body(curr_scene, hero_beam);

  for (size_t i = 1; i < scene_bodies(curr_scene); i++) {
    body_t *curr_body = scene_get_body(curr_scene, i);
    if (strcmp(body_get_info(curr_body), "Enemy") == 0) {
      create_destructive_collision(curr_scene, hero_beam, curr_body);
    }
  }
}

void populate_enemy_beam(scene_t *curr_scene, rgb_color_t color, char *info,
                         size_t center_x, size_t center_y) {
  list_t *beam_shape = make_beam(BEAM_LENGTH, BEAM_WIDTH, center_x, center_y);

  body_t *enemy_beam = body_init_with_info(beam_shape, BEAM_MASS, color, info,
                                           (free_func_t)free);
  body_set_centroid(enemy_beam, (vector_t){center_x, center_y});
  body_set_velocity(enemy_beam, vec_multiply(-1, BEAM_VELOCITY));
  scene_add_body(curr_scene, enemy_beam);

  body_t *hero = scene_get_body(curr_scene, 0);
  create_destructive_collision(curr_scene, enemy_beam, hero);
}

void on_key(char key, key_event_type_t type, double held_time, state_t *state) {
  scene_t *scene = state->scene;
  body_t *body = scene_get_body(scene, 0);
  if (type == KEY_PRESSED) {
    vector_t velocity = {X_VELOCITY, 0};
    switch (key) {
    case LEFT_ARROW:
      body_set_velocity(body, vec_negate(velocity));
      break;
    case RIGHT_ARROW:
      body_set_velocity(body, velocity);
      break;
    case SPACE:
      populate_hero_beam(scene, GREEN, "Hero Beam", body_get_centroid(body).x,
                         body_get_centroid(body).y);
    }
  } else if (type == KEY_RELEASED) {
    body_set_velocity(body, VEC_ZERO);
  }
}

void wrap_around(scene_t *curr_scene) {
  body_t *hero = scene_get_body(curr_scene, 0);
  vector_t center_hero = body_get_centroid(hero);
  if ((center_hero.x + HERO_SEMI_MAJOR) >= WINDOW.x) {
    body_set_velocity(hero, vec_negate(ENEMY_VELOCITY));
  } else if ((center_hero.x - HERO_SEMI_MAJOR) <= 0.0) {
    body_set_velocity(hero, ENEMY_VELOCITY);
  }
  size_t max_col_enemies = NUM_COLUMN_ENEMIES;

  for (size_t i = 1; i < scene_bodies(curr_scene); i++) {
    body_t *enemy = scene_get_body(curr_scene, i);
    if (strcmp(body_get_info(enemy), "Enemy") == 0) {
      vector_t center = body_get_centroid(enemy);

      if ((center.x + ENEMY_RAD) >= WINDOW.x) {
        body_set_centroid(
            enemy, (vector_t){center.x, center.y - (max_col_enemies *
                                                    ENEMY_DIAMETER / SPACING)});
        body_set_velocity(enemy, vec_negate(ENEMY_VELOCITY));
      } else if ((center.x - ENEMY_RAD) <= 0.0) {
        body_set_centroid(
            enemy, (vector_t){center.x, center.y - (max_col_enemies *
                                                    ENEMY_DIAMETER / SPACING)});
        body_set_velocity(enemy, ENEMY_VELOCITY);
      }
    }
  }
}

void populate_enemy_list(scene_t *curr_scene, rgb_color_t color, char *info,
                         size_t center_x, size_t center_y) {
  size_t x_shift = 10;
  size_t new_center_y = center_y;
  for (size_t i = 0; i < NUM_ROW_ENEMIES; i++) {
    for (size_t i = 0; i < NUM_COLUMN_ENEMIES; i++) {
      list_t *enemy_shape =
          make_invaders(ENEMY_RAD, center_x + x_shift, new_center_y);
      body_t *to_add = body_init_with_info(enemy_shape, ENEMY_MASS, color, info,
                                           (free_func_t)free);
      body_set_centroid(to_add, (vector_t){center_x + x_shift, new_center_y});
      body_set_velocity(to_add, ENEMY_VELOCITY);
      body_set_rotation(to_add, ROT_ANGLE);
      scene_add_body(curr_scene, to_add);
      new_center_y -= ENEMY_DIAMETER / SPACING;
    }
    x_shift += ENEMY_DIAMETER;
    new_center_y = center_y;
  }
}

void populate_scene_init(scene_t *curr_scene, rgb_color_t color, char *info,
                         size_t center_x, size_t center_y) {
  list_t *hero_shape = make_player(0.0, 0.0, HERO_SEMI_MINOR, HERO_SEMI_MAJOR);
  double mass = M_PI * HERO_SEMI_MAJOR * HERO_SEMI_MINOR;
  body_t *hero =
      body_init_with_info(hero_shape, mass, color, info, (free_func_t)free);
  body_set_centroid(hero, (vector_t){center_x, center_y});
  body_set_rotation(hero, THREE_HALF_PI);
  scene_add_body(curr_scene, hero);
  body_set_velocity(hero, VEC_ZERO);
  populate_enemy_list(curr_scene, GRAY, "Enemy", ENEMY_RAD,
                      WINDOW.y - ENEMY_RAD);
}

void spawn_enemy_beam(scene_t *curr_scene) {
  set_tot(curr_scene, get_tot(curr_scene) + 1);

  if ((size_t)(get_tot(curr_scene) + SPAWN_WAIT_TIME) % SPAWN_WAIT_TIME == 0) {
    body_t *hero = scene_get_body(curr_scene, 0);
    size_t hero_x = body_get_centroid(hero).x;

    body_t *closest_body = scene_get_body(curr_scene, 1);

    for (size_t i = 2; i < scene_bodies(curr_scene); i++) {
      body_t *curr_body = scene_get_body(curr_scene, i);

      if (strcmp(body_get_info(curr_body), "Enemy") == 0) {
        if (closest_body == NULL) {
          closest_body = curr_body;
        } else {
          size_t curr_x = body_get_centroid(curr_body).x;
          size_t closest_x = body_get_centroid(closest_body).x;

          if (curr_x - hero_x <= closest_x - hero_x) {
            closest_body = curr_body;
          }
        }
      }
    }
    populate_enemy_beam(curr_scene, GRAY, "Enemy Beam",
                        body_get_centroid(closest_body).x,
                        body_get_centroid(closest_body).y);
  }
}

bool player_shot(scene_t *curr_scene) {
  body_t *first = scene_get_body(curr_scene, 0);
  if (strcmp(body_get_info(first), "Hero") != 0) {
    return 1;
  }
  return 0;
}

bool cleared_enemies(scene_t *curr_scene) {
  size_t counter = 0;
  for (size_t i = 0; i < scene_bodies(curr_scene); i++) {
    body_t *curr_body = scene_get_body(curr_scene, i);
    if (strcmp(body_get_info(curr_body), "Enemy") == 0) {
      counter++;
    }
  }
  if (counter == 0) {
    return 1;
  }
  return 0;
}

bool enemy_out(scene_t *curr_scene) {
  for (size_t i = 0; i < scene_bodies(curr_scene); i++) {
    body_t *curr_body = scene_get_body(curr_scene, i);
    if (strcmp(body_get_info(curr_body), "Enemy") == 0) {
      size_t y_coord = body_get_centroid(curr_body).y;
      if (y_coord <= 0) {
        return 1;
      }
    }
  }
  return 0;
}

void check_end(scene_t *curr_scene) {
  if (player_shot(curr_scene) || cleared_enemies(curr_scene) ||
      enemy_out(curr_scene)) {
    exit(0);
  }
}

state_t *emscripten_init() {
  vector_t min = VEC_ZERO;
  vector_t max = WINDOW;

  sdl_on_key((void *)on_key);
  state_t *new_state = malloc(sizeof(state_t));

  sdl_init(min, max);
  scene_t *space_scene = scene_init();

  populate_scene_init(space_scene, GREEN, "Hero", 250, 20);

  sdl_render_scene(space_scene);
  new_state->scene = space_scene;
  return new_state;
}

void emscripten_main(state_t *state) {
  scene_t *curr_scene = state->scene;
  double dt = time_since_last_tick();

  scene_tick(curr_scene, dt);
  check_end(curr_scene);
  wrap_around(curr_scene);
  sdl_render_scene(curr_scene);
  spawn_enemy_beam(curr_scene);
}

void emscripten_free(state_t *state) {
  scene_free(state->scene);
  free(state);
}
