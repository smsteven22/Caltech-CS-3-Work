#include <assert.h>
#include <math.h>
#include <stdlib.h>

#include "body.h"
#include "color.h"
#include "forces.h"
#include "list.h"
#include "scene.h"
#include "vector.h"

#include "forces.h"
#include "test_util.h"

list_t *make_shape() {
  list_t *shape = list_init(4, free);
  vector_t *v = malloc(sizeof(*v));
  *v = (vector_t){-1, -1};
  list_add(shape, v);
  v = malloc(sizeof(*v));
  *v = (vector_t){+1, -1};
  list_add(shape, v);
  v = malloc(sizeof(*v));
  *v = (vector_t){+1, +1};
  list_add(shape, v);
  v = malloc(sizeof(*v));
  *v = (vector_t){-1, +1};
  list_add(shape, v);
  return shape;
}

double spring_total_energy(double K, double A) { return 0.5 * K * pow(A, 2); }

double spring_potential_energy(double K, double A, double M, double t) {
  return 0.5 * K * pow(A, 2) * pow(cos(sqrt(K / M) * t), 2);
}

double spring_kinetic_energy(double K, double A, double M, double t) {
  return 0.5 * K * pow(A, 2) * pow(sin(sqrt(K / M) * t), 2);
}

void test_spring_force() {
  const double M = 3;
  const double K = 12;
  const double A = 5;
  const double DT = 1e-6;
  const int STEPS = 1000000;

  scene_t *scene = scene_init();

  body_t *mass = body_init(make_shape(), M, (rgb_color_t){0, 0, 0});
  body_set_centroid(mass, (vector_t){A, 0});
  scene_add_body(scene, mass);

  body_t *anchor = body_init(make_shape(), INFINITY, (rgb_color_t){0, 0, 0});
  scene_add_body(scene, anchor);

  create_spring(scene, K, mass, anchor);

  double total_energy = spring_total_energy(K, A);

  for (int i = 0; i < STEPS; i++) {
    double energy = spring_potential_energy(K, A, M, i * DT) +
                    spring_kinetic_energy(K, A, M, i * DT);
    assert(within(1e-4, energy / total_energy, 1.0));
    scene_tick(scene, DT);
  }
  scene_free(scene);
}

double gravity_potential(double G, body_t *body1, body_t *body2) {
  vector_t r = vec_subtract(body_get_centroid(body2), body_get_centroid(body1));
  return -G * body_get_mass(body1) * body_get_mass(body2) / sqrt(vec_dot(r, r));
}

void test_gravity_force() {
  const double M1 = 10, M2 = 1, M3 = 10;
  const double G = 1e3;
  const double DT = 1e-6;
  const int STEPS = 1000000;
  scene_t *scene = scene_init();
  body_t *mass1 = body_init(make_shape(), M1, (rgb_color_t){0, 0, 0});
  body_set_centroid(mass1, (vector_t){10, 20});
  scene_add_body(scene, mass1);

  body_t *mass2 = body_init(make_shape(), M2, (rgb_color_t){0, 0, 0});
  body_set_centroid(mass2, (vector_t){0, 0});
  scene_add_body(scene, mass2);

  body_t *mass3 = body_init(make_shape(), M3, (rgb_color_t){0, 0, 0});
  body_set_centroid(mass3, (vector_t){-10, -20});
  scene_add_body(scene, mass3);

  create_newtonian_gravity(scene, G, mass1, mass2);
  create_newtonian_gravity(scene, G, mass2, mass3);

  for (int i = 0; i < STEPS; i++) {
    assert(vec_equal(body_get_centroid(mass2), (vector_t){0, 0}));
    scene_tick(scene, DT);
  }
  scene_free(scene);
}

double vec_len(vector_t vec) { return sqrt((vec.x * vec.x) + (vec.y * vec.y)); }

void test_drag_force() {
  const double M = 10;
  const double GAMMA = 500;
  const double DT = 1e-6;
  const int STEPS = 10;

  scene_t *scene = scene_init();

  body_t *mass = body_init(make_shape(), M, (rgb_color_t){0, 0, 0});
  body_set_velocity(mass, (vector_t){1000, 1000});
  body_set_centroid(mass, VEC_ZERO);
  scene_add_body(scene, mass);

  create_drag(scene, GAMMA, mass);

  vector_t curr_vel = body_get_velocity(mass);

  for (int i = 0; i < STEPS; i++) {
    scene_tick(scene, DT);
    vector_t new_vel = body_get_velocity(mass);
    assert(new_vel.x < curr_vel.x);
    assert(new_vel.y < curr_vel.y);
    curr_vel = new_vel;
  }
  scene_free(scene);
}

int main(int argc, char *argv[]) {
  bool all_tests = argc == 1;
  char testname[100];
  if (!all_tests) {
    read_testname(argv[1], testname, sizeof(testname));
  }

  DO_TEST(test_spring_force);
  DO_TEST(test_gravity_force);
  DO_TEST(test_drag_force);

  puts("student_tests PASS");
}
