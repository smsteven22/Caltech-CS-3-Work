#include "list.h"
#include "polygon.h"
#include "test_util.h"
#include "vector.h"
#include <assert.h>
#include <math.h>
#include <stdlib.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

void test_list_size0() {
  list_t *l = list_init(0, (free_func_t)free);
  assert(list_size(l) == 0);
  list_free(l);
}

void test_resizeability() {
  list_t *l = list_init(1, (free_func_t)free);
  assert(list_size(l) == 0);
  // Add
  vector_t *v = malloc(sizeof(*v));
  *v = VEC_ZERO;
  list_add(l, v);
  vector_t *q = malloc(sizeof(*q));
  list_add(l, q);
  assert(list_size(l) == 2);
  // free(v);
  // free(q);
  list_free(l);
}

void test_resize_with_remove() {
  list_t *l = list_init(1, (free_func_t)free);
  assert(list_size(l) == 0);
  // Add
  vector_t *v = malloc(sizeof(*v));
  *v = VEC_ZERO;
  list_add(l, v);
  // vector_t *q = malloc(sizeof(*q));
  // q->x = q->y = 1;
  vector_t q = {1, 1};
  list_add(l, &q);
  // to check if it's actually adding to the back
  vector_t *a = list_get(l, list_size(l) - 1);
  assert(vec_equal(*a, q));
  assert(list_size(l) == 2);
  // test if remove back reduces list size
  list_remove(l, list_size(l) - 1);
  assert(list_size(l) == 1);
  //   // test if removes from the back
  //   vector_t *after_remove = list_get(l, list_size(l) - 1);
  //   assert(vec_equal(*after_remove, *q));
  vector_t *b = malloc(sizeof(*b));
  b->x = b->y = 2;
  list_add(l, b);
  // is it adding the correct vector to the front
  //   assert(vec_equal(*b, (vector_t){2, 2}));
  assert(list_size(l) == 2);
  // free(v);
  // free(b);
  list_free(l);
}

void test_list_size1() {
  list_t *l = list_init(1, (free_func_t)free);
  assert(list_size(l) == 0);
  // Add
  // vector_t *v = malloc(sizeof(*v));
  // *v = VEC_ZERO;
  vector_t v = {0, 0};
  list_add(l, &v);
  assert(list_size(l) == 1);
  // Remove
  // assert(list_remove(l, list_size(l) - 1) == v);
  list_remove(l, list_size(l) - 1);
  assert(list_size(l) == 0);
  // Add again
  vector_t *a = malloc(sizeof(*a));
  a->x = a->y = 1;
  list_add(l, a);
  assert(list_size(l) == 1);
  vector_t *got = list_get(l, 0);
  assert(vec_equal(*got, (vector_t){1, 1}));
  // Modify
  // *v = (vector_t){1, 2};
  // assert(list_size(l) == 1);
  // vector_t *got_2 = list_get(l, 0);
  // assert(vec_equal(*got_2, (vector_t){1, 2}));
  list_free(l);
}

void test_list_small() {
  list_t *l = list_init(5, (free_func_t)free);
  assert(list_size(l) == 0);
  // Fill partially
  vector_t *v = malloc(sizeof(*v));
  *v = VEC_ZERO;
  list_add(l, v);
  vector_t *w = malloc(sizeof(*w));
  w->x = w->y = 1;
  list_add(l, w);
  vector_t *z = malloc(sizeof(*z));
  z->x = z->y = 2;
  list_add(l, z);
  assert(list_size(l) == 3);
  vector_t *got_0 = list_get(l, 0);
  vector_t *got_1 = list_get(l, 1);
  vector_t *got_2 = list_get(l, 2);
  assert(vec_equal(*got_0, VEC_ZERO));
  assert(vec_equal(*got_1, (vector_t){1, 1}));
  assert(vec_equal(*got_2, (vector_t){2, 2}));
  list_free(l);
}

#define LARGE_SIZE 1000

// Get/set elements in large list
void test_list_large_get_set() {
  list_t *l = list_init(LARGE_SIZE, (free_func_t)free);
  // Add to capacity
  for (size_t i = 0; i < LARGE_SIZE; i++) {
    vector_t *v = malloc(sizeof(*v));
    v->x = v->y = i;
    list_add(l, v);
  }
  // Check
  for (size_t i = 0; i < LARGE_SIZE; i++) {
    vector_t *check = list_get(l, i);
    assert(vec_equal(*check, (vector_t){i, i}));
  }
  // Set every 100th value
  for (size_t i = 0; i < LARGE_SIZE; i += 100) {
    vector_t *v = list_get(l, i);
    v->x = v->y = i * 10;
  }
  // Check all values again
  for (size_t i = 0; i < LARGE_SIZE; i++) {
    vector_t *check_2 = list_get(l, i);
    assert(vec_equal(*check_2, i % 100 == 0 ? (vector_t){i * 10, i * 10}
                                            : (vector_t){i, i}));
  }
  list_free(l);
}

// // Add/remove elements from a large list
void test_list_large_add_remove() {
  list_t *l = list_init(LARGE_SIZE, (free_func_t)free);
  // Add to capacity
  for (size_t i = 0; i < LARGE_SIZE; i++) {
    vector_t *v = malloc(sizeof(*v));
    v->x = v->y = i;
    list_add(l, v);
  }
  assert(list_size(l) == LARGE_SIZE);
  list_free(l);
}

typedef struct {
  list_t *list;
  size_t index;
} list_access_t;
void get_out_of_bounds(void *aux) {
  list_access_t *access = (list_access_t *)aux;
  list_get(access->list, access->index);
}
void test_out_of_bounds_access() {
  const size_t max_size = 5;
  list_access_t *access = malloc(sizeof(*access));
  access->list = list_init(max_size, (free_func_t)free);
  // This test takes several seconds to run
  fputs("test_out_of_bounds_access running...\n", stderr);

  // Try list with 0 elements, 1 element, ..., up to max_size elements
  for (size_t size = 0; size <= max_size; size++) {
    // Make sure negative indices report as out of bounds
    for (access->index = -3; (int)access->index < 0; access->index++) {
      assert(test_assert_fail(get_out_of_bounds, access));
    }

    // Assert indices greater than or equal to size are invalid
    for (access->index = size; access->index < size + 3; access->index++) {
      assert(test_assert_fail(get_out_of_bounds, access));
    }

    // Increase the size of the list by 1
    if (size < max_size) {
      list_add(access->list, malloc(sizeof(vector_t)));
    }
  }
  list_free(access->list);
  free(access);
}

void add_past_end(void *l) { list_add((list_t *)l, malloc(sizeof(vector_t))); }
void test_full_add() {
  const size_t size = 3;
  list_t *l = list_init(size, (free_func_t)free);

  // Fill list
  for (size_t i = 0; i < size; i++) {
    list_add(l, malloc(sizeof(vector_t)));
  }

  // Try adding to the full list -- should fail an assertion
  list_free(l);
}

void remove_from_empty(void *l) { list_remove((list_t *)l, list_size(l) - 1); }
void test_empty_remove() {
  const size_t size = 100;
  list_t *l = list_init(size, (free_func_t)free);

  // Fill list with copies of v, then remove them all
  vector_t v = {.x = 1, .y = -2};
  for (size_t i = 0; i < size; i++) {
    vector_t list_v = v;
    list_add(l, &list_v);
  }
  for (size_t i = 0; i < size; i++) {
    list_remove(l, list_size(l) - 1);
  }
  assert(list_size(l) == 0);

  // Try removing from the empty list -- should fail an assertion
  assert(test_assert_fail(remove_from_empty, l));
  list_free(l);
}

void add_null(void *l) { list_add(l, NULL); }
void test_null_values() {
  list_t *l = list_init(1, (free_func_t)free);
  assert(test_assert_fail(add_null, l));
  list_free(l);
}

int main(int argc, char *argv[]) {
  // Run all tests if there are no command-line arguments
  bool all_tests = argc == 1;
  // Read test name from file
  char testname[100];
  if (!all_tests) {
    read_testname(argv[1], testname, sizeof(testname));
  }

  DO_TEST(test_resizeability)
  DO_TEST(test_resize_with_remove)
  DO_TEST(test_list_size0)
  DO_TEST(test_list_size1)
  DO_TEST(test_list_small)
  DO_TEST(test_list_large_get_set)
  DO_TEST(test_list_large_add_remove)
  DO_TEST(test_out_of_bounds_access)
  DO_TEST(test_full_add)
  DO_TEST(test_empty_remove)
  DO_TEST(test_null_values)

  puts("list_test PASS");
}
